package batailleNavaleV1.comportement.D�placement;
import java.util.logging.Logger;

import batailleNavaleV1.ElementsJeux.Bateaux.Eorientation;
import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;

public class ResteSurPlace implements IDeplacable{
	
	private final static Logger LOGGER = Logger.getLogger(ResteSurPlace.class.getName());
	
	
	public void avancer(int distance) {
		immobile();
		
	}
	
	private void immobile() {
		LOGGER.info(": je reste la o� je suis!!");
	}

	public void pivoter(Eorientation orient) {
		immobile();
		
	}

	
		
	}
	

