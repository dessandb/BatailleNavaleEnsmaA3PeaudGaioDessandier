package batailleNavaleV1.comportement.Attaque;

import java.util.logging.Logger;


public class Attaqueclassique implements IAttaqueBateau {
	private final static Logger LOGGER = Logger.getLogger(Attaqueclassique.class.getName()); 


	public void aLAttaque(IAttaquable[] cibles, int puiss) {
		Tirclassique();
		for (int i = 0; i < cibles.length; i++) {
			if(cibles[i]!=null) {
			cibles[i].estAttaque(puiss);
		}
		}
		
	}
	
	private void Tirclassique() {
		LOGGER.info(" Et � la fin de l'envoi je touche !!!");
		
	}

	public void eclaireTout(IAttaquable[] cibles) {
		// TODO Auto-generated method stub
		
	}
}

