package batailleNavaleV1.AutomateBateau.etats;

import batailleNavaleV1.AutomateBateau.ActionNonPossibleException;
import batailleNavaleV1.AutomateBateau.IGestionEtat;

public class auRepos extends AbstractEtat {
	public auRepos(IGestionEtat aut) {
		super(aut);
	}
	
	@Override
	public void deplacer() throws ActionNonPossibleException {
		autom.setEtatCourant(autom.getEnDeplacement());
	}
	
	@Override
	public void ALAttaque() throws ActionNonPossibleException {
		autom.setEtatCourant(autom.getEnAttaque());
	}
}
