package batailleNavaleV1.AutomateBateau.etats;

import batailleNavaleV1.AutomateBateau.ActionNonPossibleException;
import batailleNavaleV1.AutomateBateau.IGestionEtat;

public class enAttaque extends AbstractEtat {
	
	public enAttaque(IGestionEtat aut) {
		super(aut);
	}
	
	@Override
	public void arret() throws ActionNonPossibleException {
		autom.setEtatCourant(autom.getAuRepos());
	}
	
	@Override
	public void deplacer() throws ActionNonPossibleException {
		autom.setEtatCourant(autom.getEnDeplacement());
	}

	
}
