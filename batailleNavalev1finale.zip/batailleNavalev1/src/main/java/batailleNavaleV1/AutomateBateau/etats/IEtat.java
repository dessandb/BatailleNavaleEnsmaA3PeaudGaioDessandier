package batailleNavaleV1.AutomateBateau.etats;

import batailleNavaleV1.AutomateBateau.ActionNonPossibleException;
public interface IEtat extends IEtatBase {
	public void ALAttaque()throws ActionNonPossibleException;
}
