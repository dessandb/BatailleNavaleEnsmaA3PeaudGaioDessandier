package batailleNavaleV1.ElementsJeux.Bateaux;

import java.util.logging.Logger;

import batailleNavaleV1.comportement.Attaque.Attaqueclassique;
import batailleNavaleV1.comportement.Attaque.IAttaqueBateau;
import batailleNavaleV1.comportement.Attaque.IEclairable;
import batailleNavaleV1.comportement.D�placement.Enpivotant;
import batailleNavaleV1.plateauJeu.Case;

public class Croiseur  extends AbsBateau implements IAttaqueBateau {
	
	private static final int longueur = 4;
	private static final int nbLignes = 1;
	private final static Logger LOGGER = Logger.getLogger(Croiseur.class.getName());
	public Croiseur() {
		pv = new Case[nbLignes-1][longueur-1];
		for(int i=0 ; i<longueur ; i++) {
			pv[0][i]=new Case(getCaseorigine().getAbcisse(),getCaseorigine().getOrdonn�e(),longueur);
		}
		comportementAttaque= new Attaqueclassique();
		comportementDeplacement=new Enpivotant();
	}
	
	public int getLongueur() {
		return longueur;
	}

	public static int getNblignes() {
		return nbLignes;
	}

	public int[] eclaireTout(IEclairable[] cibles) {
		return null;
		// TODO Auto-generated method stub
		
	}

		

	}