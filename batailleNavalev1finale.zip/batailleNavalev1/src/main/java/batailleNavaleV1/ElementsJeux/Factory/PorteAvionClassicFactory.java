package batailleNavaleV1.ElementsJeux.Factory;

import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;
import batailleNavaleV1.ElementsJeux.Bateaux.PorteAvionClassic;

public class PorteAvionClassicFactory extends AbsFactory {
	
	@Override
	public IBateau createBateau() {
		return new PorteAvionClassic();
	}
}
