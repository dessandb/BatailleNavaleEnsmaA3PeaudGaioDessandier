package batailleNavaleV1.ElementsJeux.Factory;

import batailleNavaleV1.ElementsJeux.Bateaux.Eelementjeu;
import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;

public abstract class AbsFactory {

	public static AbsFactory createFactory(Eelementjeu el) {
		AbsFactory fact;
		switch(el) {
		case PORTE_AVION_CLASSIC:
			fact = new PorteAvionClassicFactory();
			return fact;
		case PORTE_AVION_MODIFIE:
			fact = new PorteAvionModifieFactory();
			return fact;
		case CONTRE_TORPILLEUR:
			fact = new ContreTorpilleurFactory();
			return fact;
		case CROISEUR:
			fact = new CroiseurFactory();
			return fact;
		case SOUS_MARIN:
			fact = new SousMarinFactory();
			return fact;
		case TORPILLEUR:
			fact = new TorpilleurFactory();
			return fact;
		case VOILIER2:
			fact = new VoilierFactory();
			return fact;
		//Default case : Voilier1
		default:
			fact = new VoilierFactory();
			return fact;
		}
		
	}
	
	
	public abstract IBateau createBateau();
	
}
