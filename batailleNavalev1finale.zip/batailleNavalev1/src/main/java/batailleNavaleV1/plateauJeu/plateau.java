package batailleNavaleV1.plateauJeu;

public class plateau {

	private int[][] pl= new int[10][10];
	
	public plateau() {
		for (int abc = 0; abc < pl.length; abc++) {
			for(int ord=0; ord<pl.length; ord++) {
				this.pl[abc][ord]=0;
			}
		};
	}

	public int[][] getPl() {
		return pl;
	}

	public void placerBateauplateau(Case[][] matricebateau) {
		for (int i = 0; i < matricebateau[0].length; i++) {
			if (estOccupee(matricebateau[0][i].getAbcisse(),matricebateau[0][i].getOrdonn�e())==false){
			this.pl[matricebateau[0][i].getAbcisse()][matricebateau[0][i].getOrdonn�e()] = matricebateau[0][i].getR�sistance();
		
			}
		}
		if(matricebateau[1].length>0) {
			for(int i =0; i < matricebateau[1].length; i++) {
				if (estOccupee(matricebateau[1][i].getAbcisse(),matricebateau[1][i].getOrdonn�e())==false){
				this.pl[matricebateau[1][i].getAbcisse()][matricebateau[1][i].getOrdonn�e()] = matricebateau[1][i].getR�sistance();
				}
			}
		}
	}
	
	public void enleverBateauplateau(Case[][] matricebateau) {
		for (int i = 0; i < matricebateau[0].length; i++) {
			this.pl[matricebateau[0][i].getAbcisse()][matricebateau[0][i].getOrdonn�e()] =0;
		}
		if(matricebateau[1].length>0) {
			for(int i =0; i < matricebateau[1].length; i++) {
				this.pl[matricebateau[1][i].getAbcisse()][matricebateau[1][i].getOrdonn�e()] = 0;
			}
		}
	}
	public boolean estOccupee(int abc,int ord) {
		if(findCase(abc,ord).getR�sistance()!=0) {
			return false;
		}
		else {
			return true;
		}
	}
	public Case findCase(int abc, int ord) {
		 Case c =new Case(0,0,0);
		 c.setAbcisse(abc);
		 c.setOrdonn�e(ord);
		 c.setR�sistance(pl[abc][ord]);
		 return c;
		  }
	public Case Up(Case c) {
		if (c.getOrdonn�e()>0){
			int	ord=c.getOrdonn�e()-1;
			int abc=c.getAbcisse();
			return findCase(abc,ord);
		}
		else {
			System.out.println("Il n'y a pas de case au dessus");
			return null;
		}
	}
	
	public Case Down(Case c) {
		if (c.getOrdonn�e()<10) {
			int	ord=c.getOrdonn�e()+1;
			int abc=c.getAbcisse();
			return findCase(abc,ord); 
		}
		else {
			System.out.println("Il n'y a pas de case en dessous");
			return null;
		}
	}
	
	public Case Left(Case c) {
		if(c.getAbcisse()>1) {
			int	ord=c.getOrdonn�e();
			int abc=c.getAbcisse()-1;
			return findCase(abc,ord); 
		}
		else {
			System.out.println("Il n'y a pas de case � gauche");
			return null;
		}
	}
	
	public Case Right(Case c) {
		if(c.getAbcisse()<10) {
			int	ord=c.getOrdonn�e();
			int abc=c.getAbcisse()+1;
			return findCase(abc,ord); 
		}
		else {
			System.out.println("Il n'y a pas de case � droite");
			return null;
		}
	}
	
	public Case[] Encroix(Case c){ 
		Case[] T= {c,Right(c),Left(c),Up(c),Down(c)};
		return T; 
	}
	public Case[] Rayon(Case c) {
		Case[] T= {c,
				/* premier cercle*/
				Up(c),Up(Right(c)),Right(c),Down(Right(c)),Down(c),Down(Left(c)),Left(c),
				/* second cercle*/ 
				Up(Up(c)),Up(Up(Right(c))),Up(Up(Right(Right(c)))),Up(Right(Right(c))),Right(Right(c)),Down(Right(Right(c))),Down(Down(Right(Right(c)))),Down(Down(Right(c))),Down(Down(c)),Down(Down(Left(c))),Down(Down(Left(Left(c)))),Down(Left(Left(c))),Left(Left(c)),Up(Left(Left(c))),Up(Up(Left(Left(c)))),Up(Up(Left(c)))};
		return T;
	}
	
	public Case[] Eclairee(Case c,int res) {
		Case[] T=new Case[(res)*(res)];
		T[0]=c;
		for ( int j=0; j<res ;j++) {
			for (int i = 0; i < res; i++) {
				T[(j)*(res+1)+i+1]=Right(T[j*(res+1)+i]);
			}
			T[(j+1)*(res+1)]=Down(T[(j)*(res+1)]);
		}
		return T;
		
	}
}
	
