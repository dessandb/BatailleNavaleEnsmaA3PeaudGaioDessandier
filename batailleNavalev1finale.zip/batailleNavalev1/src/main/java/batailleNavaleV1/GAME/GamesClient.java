package batailleNavaleV1.GAME;

import batailleNavaleV1.ElementsJeux.Bateaux.Eelementjeu;

public class GamesClient {
	private int nbtourj1=0;
	private int nbtourj2=0;
	private int nbtourstotal=0;
	private int nbtoursskipj1=0;
	private int nbtoursskipj2=0;
	private Joueur Joueur1;
	private JoueurIA computer;

	
	public GamesClient(String namejoueur1, String namecomputer) {
		Joueur1= new Joueur(namejoueur1);
		computer=new JoueurIA(namecomputer);
	}
	
	public void BonusDefense(Eelementjeu el) {
		if(Joueur1.getMissattaq()==3) {
			computer.getFlottejoueur().getBateau(el).upgradepv();
			Joueur1.setMissattaq(0);
		}
		if(computer.getMissattaq()==3) {
			Joueur1.getFlottejoueur().getBateau(el).upgradepv();
			computer.setMissattaq(0);
		}
		
	}
	
	public void BonusAttaque() {
		if(Joueur1.getSuccessattaq()==2) {
			Joueur1.UpgradeAttaq();
			Joueur1.setSuccessattaq(0);
		}
		if(computer.getSuccessattaq()==2) {
			computer.UpgradeAttaq();
			computer.setSuccessattaq(0);
		}
		
	}
	
	public void ChangementTour() {
		if(Joueur1.getTourjoueur()==Eaction.END_TOUR){//(Joueur1.getTourjoueur()==Eaction.SKIP)) {
			this.nbtourj1++;
			this.nbtourstotal++;
			computer.setTourjoueur(Eaction.NOT_PLAYED);
		}
		if(Joueur1.getTourjoueur()==Eaction.SKIP) {
			this.nbtourj1++;
			this.nbtourstotal++;
			this.nbtoursskipj1--;
			computer.setTourjoueur(Eaction.NOT_PLAYED);
			if(this.nbtoursskipj1==0) {
				Joueur1.setTourjoueur(Eaction.END_TOUR);
			}
		}
		if(computer.getTourjoueur()==Eaction.END_TOUR) {
			this.nbtourj2++;
			this.nbtourstotal++;
			Joueur1.setTourjoueur(Eaction.NOT_PLAYED);
		}
		if(computer.getTourjoueur()==Eaction.SKIP) {
			this.nbtourj2++;
			this.nbtourstotal++;
			this.nbtoursskipj2--;
			Joueur1.setTourjoueur(Eaction.NOT_PLAYED);
			if(this.nbtoursskipj2==0) {
				computer.setTourjoueur(Eaction.END_TOUR);
			}
		}
		
	}
	
	public void SkipTourJoueur() {
		if(Joueur1.getTourjoueur()==Eaction.FUSEE){
			Joueur1.setTourjoueur(Eaction.SKIP);
			this.nbtoursskipj1=5;
		}
		if(computer.getTourjoueur()==Eaction.FUSEE) {
			computer.setTourjoueur(Eaction.SKIP);
			this.nbtoursskipj2=5;
		}
		if(Joueur1.getTourjoueur()==Eaction.ATTAQUEENCROIX){
			Joueur1.setTourjoueur(Eaction.SKIP);
			this.nbtoursskipj1=3;
		}
		if(computer.getTourjoueur()==Eaction.ATTAQUEENCROIX) {
			computer.setTourjoueur(Eaction.SKIP);
			this.nbtoursskipj2=3;
		}
	}
	/*public void Timerexceeded() {
		int period=60;
		if(Joueur1.getTourjoueur()==Eaction.NOT_PLAYED) {
			
		}
	}*/
	
	public void JouerTour() {
		this.BonusAttaque();
		this.SkipTourJoueur();
		this.ChangementTour();
	}
	

}
