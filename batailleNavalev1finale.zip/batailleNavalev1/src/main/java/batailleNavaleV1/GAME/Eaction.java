package batailleNavaleV1.GAME;

public enum Eaction {
	NOT_PLAYED,ATTAQUER,ATTAQUEENCROIX,DEPLACER,FUSEE,SKIP,END_TOUR
}
