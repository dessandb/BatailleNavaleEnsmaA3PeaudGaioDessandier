package application;

import IHM.PresentationAgentGlobal;
import batailleNavaleV1.GAME.GamesClient;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainGlobal extends Application{
	@Override
	public void start(Stage primaryStage) throws Exception {
		try {
			GamesClient game;
			game.getInstance();
			PresentationAgentGlobal pg = new PresentationAgentGlobal();
			Scene scene = new Scene(pg.getSt(),400,400);
			primaryStage.setTitle("BATAILLE NAVALE");
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setMinHeight(800);
			primaryStage.setMinWidth(800);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
