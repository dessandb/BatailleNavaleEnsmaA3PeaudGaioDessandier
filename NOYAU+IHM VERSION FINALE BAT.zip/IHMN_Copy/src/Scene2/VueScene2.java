package Scene2;

import AgentPlateau.IVueAgentPlateau;
import Scene3_Joueur1.PresentationScene3_Joueur1;
import Scene3_Joueur1.VueScene3_Joueur1;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class VueScene2 extends BorderPane implements EventHandler<ActionEvent>,IVueScene2{

	private PresentationScene2 pres;
	
	private VBox vb;
	private Button ok,retour;
	
	public VueScene2(PresentationScene2 p) {
		super();
		pres=p;
		Label introduction = new Label("Veuillez placer vos bateaux");
		this.setTop(introduction);
		BorderPane.setAlignment(introduction, Pos.TOP_CENTER);
		this.setCenter(pres.getVuePlateau());
		BorderPane.setAlignment(pres.getVuePlateau(), Pos.CENTER);
		String styleCommandes= "-fx-background-color: rgba(255, 255, 255, 1);"; //rgba(230, 255, 90, 1);
		setStyle(styleCommandes);
		ok=new Button("OK");
		ok.addEventHandler(ActionEvent.ACTION, this);
		retour=new Button("retour"); 
		retour.addEventHandler(ActionEvent.ACTION, this);
		vb=new VBox();
		vb.getChildren().addAll(ok,retour);
		
		pres.getSt().getChildren().add(this);
		
		this.setLeft(pres.getvCBox());
	}
	
	public PresentationScene2 getPres() {
		return pres;
	}

	public void setPres(PresentationScene2 pres) {
		this.pres = pres;
	}
	
	@Override
	public void handle(ActionEvent event) {
		if (event.getSource()==retour) {
			pres.revenirSurSonChoix();
			choixBoutonRetour();
			
		}
		if (event.getSource()==ok) {
			  PresentationScene3_Joueur1 prezIHM = new PresentationScene3_Joueur1(
					  pres.getLigne(), pres.getColonne(), pres.getSt());
			  prezIHM.setPrezPlateauJoueur(pres.getPrezPlateau());
			  prezIHM.setVuePlateauJoueur(pres.getVuePlateau());
			  VueScene3_Joueur1 vueIHM = new VueScene3_Joueur1(prezIHM);
			  prezIHM.setVuePartie(vueIHM);;
			  pres.getSt().getChildren().add(vueIHM);
		}
	}

	@Override
	public void createBoutonAccord() {
		if (pres.getNbCasesTouchees()<5) {
			this.setRight(retour);
		}
		else {ok=new Button("OK");
		ok.addEventHandler(ActionEvent.ACTION, this);
		retour=new Button("retour"); 
		retour.addEventHandler(ActionEvent.ACTION, this);
		vb=new VBox();
		vb.getChildren().addAll(ok,retour);
			this.setRight(vb);}
		retour.addEventHandler(ActionEvent.ACTION, this);
		}

	@Override
	public void choixBoutonRetour() {
	pres.setNbCasesTouchees(pres.getNbCasesTouchees()-1);
	this.getChildren().removeAll(pres.getVuePlateau());
	if (pres.getNbCasesTouchees()==0) {
		this.getChildren().removeAll(vb);
	}
	else if (pres.getNbCasesTouchees()==4) {
		vb.getChildren().remove(ok);
	}
	Label labTop = new Label("PLATEAU ADVERSE");
	VBox vTop = new VBox();
	vTop.getChildren().addAll(labTop,pres.getVuePlateau());
	vTop.setAlignment(Pos.CENTER);
	this.setTop(vTop);

	}
}
