package Scene2;

public interface IVueScene2 {
	public void createBoutonAccord();
	public void choixBoutonRetour();
}
