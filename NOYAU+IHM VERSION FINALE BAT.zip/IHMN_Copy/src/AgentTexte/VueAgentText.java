package AgentTexte;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;

public class VueAgentText extends VBox implements EventHandler<KeyEvent>, IVueChampText{
	
	private PresentationAgentText pres;
			
	private Label labChT;
	private TextField txtF;
	
	public VueAgentText(final PresentationAgentText p) {
		pres = p;
		labChT = new Label(pres.getLeLabel());
		txtF = new TextField();
		txtF.setEditable(pres.getEditChamp());
		txtF.setDisable(!pres.getEnableChamp());
		getChildren().addAll(labChT, txtF);
		setMinWidth(200d);
		labChT.setAlignment(Pos.CENTER);
		txtF.addEventFilter(KeyEvent.KEY_TYPED, this);
		txtF.setText("");
	}
	
	
	@Override
	public void handle(KeyEvent event) {
		pres.actionTouche(txtF.getText()+event.getCharacter().toString());
		event.consume();
		if(txtF.getText()!=null) {
			txtF.positionCaret(txtF.getText().length());
		}
	}

	@Override
	public void notifValeur(String val) {
		txtF.setText(val);		
	}


	@Override
	public void notifEnable(Boolean enab) {
		txtF.setDisable(!enab);
	}


	@Override
	public void notifEditable(Boolean edit) {
		txtF.setEditable(edit);
	}

}
