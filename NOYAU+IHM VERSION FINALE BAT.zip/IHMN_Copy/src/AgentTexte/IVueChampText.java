package AgentTexte;

public interface IVueChampText {
	public void notifValeur(final String val);
	public void notifEnable(Boolean enab);
	public void notifEditable(Boolean edit);
}
