package Scene3_Joueur1;

public interface IVueScene3_Joueur1 {
	void createBoutonAccord(String msg, int i);
	void choixBoutonRetour(int i);
}
