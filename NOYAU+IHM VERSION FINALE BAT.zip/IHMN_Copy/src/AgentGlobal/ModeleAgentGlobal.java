package AgentGlobal;

import batailleNavaleV1.ElementsJeux.Bateaux.Eelementjeu;
import batailleNavaleV1.ElementsJeux.Bateaux.Eorientation;
import batailleNavaleV1.GAME.Eaction;
import batailleNavaleV1.GAME.GamesClient;
import batailleNavaleV1.comportement.Attaque.IAttaqueBateau;

public class ModeleAgentGlobal {
	private GamesClient game;
	
	 //CONFERE LE BONUS DEFENSIF AU JOUEUR EN CHOISISSANT SON BATEAU PAR Eelement
		public void BonusDefense(Eelementjeu el) {
			game.BonusDefense(el);

		}
		// PERMET DE GERER LA FIN DU TOUR LORSQUE LE JOUEUR A EFFECTUE UNE ACTION OU PASSE SON TOUR
		public void FINTOUR() {
			game.FINTOUR();
			}
			
		// PERMET DE REALISER L'ENSEMBLE DES ACTIONS DE L'IA PENDANT UN TOUR DE JEU
		public void TOURIA() {
			game.TOURIA();
		}
		// PERMET DE REALISER L'ATTAQUE DU JOUEUR
		public void ATTAQUER(Eelementjeu el, int abc, int ord,IAttaqueBateau comportAttq){
			game.ATTAQUER(el, abc, ord, comportAttq);
		}
		// PERMET AU JOUEUR D'AVANCER SON BATEAU
		public void AVANCER(Eelementjeu el, int dist) {
			game.AVANCER(el, dist);
		}
		// PERMET AU JOUEUR DE PIVOTER SON BATEAU
		public void PIVOTER(Eelementjeu el, Eorientation or) {
			game.PIVOTER(el, or);
		}
		// PERMET AU JOUEUR DE LANCER UNE FUSEE S'IL EN A UNE
		public void FUSEE(Eelementjeu el,int abc,int ord) {
			game.FUSEE(el, abc, ord);
		}
		// PERMET AU JOUEUR DE PLACER SES BATEAUX A L'INITIALISATION
		public void PLACEBATEAU(Eelementjeu el, int abc, int ord, Eorientation or) {
			game.PLACEBATEAU(el, abc, ord, or);;
		}

	}
