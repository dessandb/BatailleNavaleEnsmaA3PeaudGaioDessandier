package AgentPlateau.agentCase;

public interface IVueAgentCase {
	public void notifEditCase();
	public void notifValCase();
	public void setTexte(String txt);
	public void setTaille(int ta);
}
