package IHM;

public class VueAgentGlobal {

}
