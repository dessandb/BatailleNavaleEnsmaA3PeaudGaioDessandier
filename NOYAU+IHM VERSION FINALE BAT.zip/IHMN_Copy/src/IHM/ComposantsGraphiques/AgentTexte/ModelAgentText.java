package IHM.ComposantsGraphiques.AgentTexte;

public class ModelAgentText {

	private String valChamp;

	public ModelAgentText() {
		valChamp = "";
	}
	
	public String getValChamp() {
		return valChamp;
	}

	public Boolean setValChamp(final String v) {
		if (v.matches("\\d+(\\.\\d*)?|\\.\\d+") || v.compareTo("") == 0) {
			valChamp = v;
			return true;
		}
		return false;
	}
	
}
