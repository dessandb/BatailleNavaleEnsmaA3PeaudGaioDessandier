package IHM.Scenes.Scene2;

import java.util.ArrayList;

import IHM.AgentPlateau.IAgentPlateauObservable;
import IHM.AgentPlateau.PresentationAgentPlateau;
import IHM.AgentPlateau.VueAgentPlateau;
import IHM.AgentPlateau.agentCase.PresentationAgentCase;
import IHM.ComposantsGraphiques.AgentComboBox.IAgentComboBoxObservable;
import IHM.ComposantsGraphiques.AgentComboBox.PresentationAgentComboBox;
import IHM.ComposantsGraphiques.AgentComboBox.VueAgentComboBox;
import IHM.Scenes.Scene3.IObservateurScene3_Joueur1;
import IHM.Scenes.Scene3.PresentationScene3_Joueur1;
import IHM.Scenes.Scene3.VueScene3_Joueur1;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;

public class PresentationScene2 implements IObservateurScene3_Joueur1,IAgentPlateauObservable, IAgentComboBoxObservable{
	/*En reliant l'instances des bateaux ici, on devra ensuite instancier les bateaux dans une liste pour qu'ils puissent etre 
	 * affiches
	 * On doit recuperer le nombre de bateaux et ainsi modifier les 4 et 5 en
	 * getListeBateaux.size() et getListeBateaux.size()-1*/
	
	/*L'id�al c'est que quand tous les bateaux sont places, on puisse cliquer juste sur ok
	 * et pas sur les autres cases du tableau*/
	
	private ArrayList<String> listeNomBateaux;
	
	private IVueScene2 vueScene2;
	private ModeleScene2 modScene2;
	
	private PresentationAgentPlateau prezPlateau;
	private VueAgentPlateau vuePlateau;
	
	private int ligne,colonne,nbCasesTouchees;
	
	private Boolean bateauPlaces,etatAvant;
	
	private PresentationAgentCase caseTouchee;
	
	private PresentationAgentComboBox pCBox;
	private VueAgentComboBox vCBox;

	private StackPane st;

	private ArrayList<IObservateurScene2> observateurs;
	
	private PresentationScene3_Joueur1 prezScene3;
	private VueScene3_Joueur1 vueScene3;
	
	public PresentationScene2(int l,int c,StackPane st) {

		modScene2 = new ModeleScene2();
		ligne=l;
		colonne=c;
		
		prezPlateau = new PresentationAgentPlateau(ligne, colonne);
		vuePlateau = new VueAgentPlateau(prezPlateau);
		vuePlateau.setMaxSize(450, 450);
		vuePlateau.setHgap(0);
		prezPlateau.setVue(vuePlateau);
		prezPlateau.ajouterObservateur(this);
		
		nbCasesTouchees = prezPlateau.getNbCasesTouchees();
		bateauPlaces=false;
		etatAvant=false;
		this.st=st;
		
		caseTouchee=null;
		
		pCBox = new PresentationAgentComboBox(true,false);
		vCBox = new VueAgentComboBox(pCBox);
		pCBox.setVue(vCBox);
		
		pCBox.ajouterObservateur(this);
		
		observateurs = new ArrayList<IObservateurScene2>();
	
		prezScene3 = null;
		vueScene3 = null;
		
		listeNomBateaux = new ArrayList<String>();
		ajouterNomBateau("test 1");
		ajouterNomBateau("test 2");
		ajouterNomBateau("test 3");
		ajouterNomBateau("test 4");
		ajouterNomBateau("test 5");
	}
	
	public ArrayList<String> getListeNomBateaux() {
		return listeNomBateaux;
	}
	public void setListeNomBateaux(ArrayList<String> listeNomBateaux) {
		this.listeNomBateaux = listeNomBateaux;
	}
	
	public void ajouterNomBateau(String e) {
		listeNomBateaux.add(e);
	}
	
	public void enleverNombateau(String e) {
		listeNomBateaux.remove(e);
	}
	
	public PresentationScene3_Joueur1 getPrezScene3() {
		return prezScene3;
	}


	public void setPrezScene3(PresentationScene3_Joueur1 prezScene3) {
		this.prezScene3 = prezScene3;
	}


	public VueScene3_Joueur1 getVueScene3() {
		return vueScene3;
	}


	public void setVueScene3(VueScene3_Joueur1 vueScene3) {
		this.vueScene3 = vueScene3;
	}


	public StackPane getSt() {return st;}
	public void setSt(StackPane st) {this.st = st;}
	
	public PresentationAgentComboBox getpCBox() {return pCBox;}
	public void setpCBox(PresentationAgentComboBox pCBox) {this.pCBox = pCBox;}
	public VueAgentComboBox getvCBox() {return vCBox;}
	public void setvCBox(VueAgentComboBox vCBox) {this.vCBox = vCBox;}

	public Boolean getBateauPlaces() {if (nbCasesTouchees==5) {bateauPlaces=true;}
									else {bateauPlaces=false;}
									return bateauPlaces;}

	public PresentationAgentPlateau getPrezPlateau() {return prezPlateau;}
	public void setPrezPlateau(PresentationAgentPlateau prezPlateau) {this.prezPlateau = prezPlateau;}
	public VueAgentPlateau getVuePlateau() {return vuePlateau;}
	public void setVuePlateau(VueAgentPlateau vuePlateau) {this.vuePlateau = vuePlateau;}
	public int getLigne() {return ligne;}
	public void setLigne(int ligne) {this.ligne = ligne;}
	public int getColonne() {return colonne;}
	public void setColonne(int colonne) {this.colonne = colonne;}
	public void setVueScene2(IVueScene2 vueScene2) {this.vueScene2 = vueScene2;}
	public IVueScene2 getVueScene2() {return vueScene2;}
	public void setBateauPlaces(Boolean bateauPlaces) {this.bateauPlaces = bateauPlaces;}
	public Boolean getEtatAvant() {return etatAvant;}
	public void setEtatAvant(Boolean etatAvant) {this.etatAvant = etatAvant;}
	public int getNbCasesTouchees() {return nbCasesTouchees;}
	public void setNbCasesTouchees(int nbCasesTouchees) {this.nbCasesTouchees = nbCasesTouchees;getPrezPlateau().setNbCasesTouchees(getPrezPlateau().getNbCasesTouchees()-1);}
	public PresentationAgentCase getCaseTouchee() {return caseTouchee;}
	public void setCaseTouchee(PresentationAgentCase caseTouchee) {this.caseTouchee = caseTouchee;}

	
	public void revenirSurSonChoix() {
		prezPlateau.setEditCase(prezPlateau.getDerniereCaseTouchee().getPositionColonne(), prezPlateau.getDerniereCaseTouchee().getPositionLigne(), !prezPlateau.getDerniereCaseTouchee().getEditCase());
		vuePlateau = new VueAgentPlateau(prezPlateau);
		prezPlateau.setVue(vuePlateau);
	}
	public void ChoisirCase() {
		vueScene2.createBoutonAccord();
	}
	
	@Override
	public void notifyAgentPlateau(int i) {
		nbCasesTouchees=i;
		ChoisirCase();
		/*Ici on devra faire que lorsqu'on touche une case et on lit la valeur de la comboBox 
		 * (pCBox.getVal()={0 pour haut, 1 pour bas, 2 pour gauche, 3 pour droite)
		 * les autres cases liees au bateau seront non Editables (cliquables)
		 * */
		System.out.println("ON EST LA");
		caseTouchee=prezPlateau.getDerniereCaseTouchee();
		notifyAgents();
	}

	public void ajouterObservateur (IObservateurScene2 obs) {observateurs.add(obs);}
	public void enleverObservateur (IObservateurScene2 obs) {if (!observateurs.contains(obs)) {observateurs.remove(obs);}}
	public void notifyAgents() {for (IObservateurScene2 agent : observateurs) {agent.notifyScene2();}}

	public void ajouterEnfant(StackPane st ,Node node) {
		st.getChildren().remove(0);
		st.getChildren().add(node);
		setSt(st);
	}

	@Override
	public void notifyComboBoxAgents() {}


	@Override
	public void notifyScene3() {

	}
	
}
