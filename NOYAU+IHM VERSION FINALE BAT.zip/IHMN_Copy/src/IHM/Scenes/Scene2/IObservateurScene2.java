package IHM.Scenes.Scene2;

public interface IObservateurScene2 {
	public void notifyScene2();
}
