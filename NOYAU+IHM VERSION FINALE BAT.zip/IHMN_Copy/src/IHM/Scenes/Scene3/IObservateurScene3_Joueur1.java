package IHM.Scenes.Scene3;

public interface IObservateurScene3_Joueur1 {
	public void notifyScene3();
}
