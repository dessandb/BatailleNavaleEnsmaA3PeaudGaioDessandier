package IHM;

import IHM.Scenes.Scene1.IObservateurScene1;
import IHM.Scenes.Scene1.PresentationScene1;
import IHM.Scenes.Scene1.VueScene1;
import IHM.Scenes.Scene2.IObservateurScene2;
import IHM.Scenes.Scene2.PresentationScene2;
import IHM.Scenes.Scene2.VueScene2;
import IHM.Scenes.Scene3.IObservateurScene3_Joueur1;
import javafx.scene.layout.StackPane;

public class PresentationAgentGlobal implements IObservateurScene1{
	//A REMPLIR ET S'inspirer du MainGlobal
	
	private PresentationScene1 prezScene1;
	private VueScene1 vueScene1;
	
	private PresentationScene2 prezScene2;
	private VueScene2 vueScene2;
	
	private StackPane st;
	
	public StackPane getSt() {
		return st;
	}

	public PresentationAgentGlobal() {
		st = new StackPane();
		
		prezScene2 = new PresentationScene2(10, 15,st);
		vueScene2 = new VueScene2(prezScene2);
		prezScene2.setVueScene2(vueScene2);
		
		prezScene1 = new PresentationScene1(vueScene2,prezScene2,st);
		vueScene1 = new VueScene1(prezScene1) ;
		prezScene1.setVueScene1(vueScene1);
		st.getChildren().addAll(vueScene1);
		prezScene1.setSt(st);
	}

	@Override
	public void notifyAgentScene1() {
		// TODO Auto-generated method stub
		
	}
	
}
