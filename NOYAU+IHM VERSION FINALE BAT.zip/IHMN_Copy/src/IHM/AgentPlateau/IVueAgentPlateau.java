package IHM.AgentPlateau;

public interface IVueAgentPlateau {

}
