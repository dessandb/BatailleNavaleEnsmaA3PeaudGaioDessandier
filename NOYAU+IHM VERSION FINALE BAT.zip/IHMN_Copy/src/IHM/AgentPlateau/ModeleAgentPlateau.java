package IHM.AgentPlateau;

public class ModeleAgentPlateau {

}
