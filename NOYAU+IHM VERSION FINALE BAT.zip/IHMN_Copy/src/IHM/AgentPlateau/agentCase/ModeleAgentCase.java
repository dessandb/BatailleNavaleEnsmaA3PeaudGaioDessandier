package IHM.AgentPlateau.agentCase;

public class ModeleAgentCase {

	private String valCase;
	private Boolean enableCase;
	public ModeleAgentCase () {
		enableCase=true;
		valCase="";
	}
	
	public Boolean getEnableCase() {return enableCase;}
	public void setEnableCase(Boolean enableCase) {this.enableCase = enableCase;}
	public String getValCase() {return valCase;}
	
	public Boolean setValCase (final String v) {
		if (valCase!="") {
			valCase=v;
			return true;
		}
		return false;
	}
}
