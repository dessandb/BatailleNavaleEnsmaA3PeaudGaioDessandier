package IHM;

public interface IVueAgentGlobal {

}
