package AgentChronometre;

public interface IVueChronometre {
	public void relancerChronoAZero ();
	public void arretChrono();
	public void demarrerChrono(int i);
}
