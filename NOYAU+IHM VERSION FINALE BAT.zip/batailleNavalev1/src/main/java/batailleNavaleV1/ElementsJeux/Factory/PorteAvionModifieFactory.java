package batailleNavaleV1.ElementsJeux.Factory;

import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;
import batailleNavaleV1.ElementsJeux.Bateaux.PorteAvionModifie;

public class PorteAvionModifieFactory extends AbsFactory {
	
	@Override
	public IBateau createBateau() {
		return new PorteAvionModifie();
	}

}
