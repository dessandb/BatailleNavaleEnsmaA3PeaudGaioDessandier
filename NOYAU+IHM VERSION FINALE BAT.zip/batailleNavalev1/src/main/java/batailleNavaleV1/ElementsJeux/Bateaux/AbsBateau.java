package batailleNavaleV1.ElementsJeux.Bateaux;

import batailleNavaleV1.AutomateBateau.ActionNonPossibleException;
import batailleNavaleV1.AutomateBateau.IGestionEtat;
import batailleNavaleV1.AutomateBateau.etats.IEtat;
import batailleNavaleV1.AutomateBateau.etats.IEtatBase;
import batailleNavaleV1.AutomateBateau.etats.auRepos;
import batailleNavaleV1.AutomateBateau.etats.enAttaque;
import batailleNavaleV1.AutomateBateau.etats.enDeplacement;

import batailleNavaleV1.plateauJeu.Case;
//import batailleNavaleV1.plateauJeu.plateau;

import batailleNavaleV1.comportement.Attaque.AttaquePas;
import batailleNavaleV1.comportement.Attaque.IAttaquable;
import batailleNavaleV1.comportement.Attaque.IAttaqueBateau;
import batailleNavaleV1.comportement.D�placement.IDeplacable;
import batailleNavaleV1.comportement.D�placement.ResteSurPlace;

import java.util.Random;

//import batailleNavaleV1.Groupement.IGroupeDep;
//import batailleNavaleV1.comportement.IGroupableDeplacable;

import java.util.logging.Logger;


public abstract class AbsBateau implements IBateau,IEtatBase,IGestionEtat,IDeplacable{//IGroupableDeplacable {
	
	protected Case[][] pv;
	protected Case caseorigine= new Case();
	protected Eorientation orient=Eorientation.DROITE;
//	private plateau plateaujoueur;
	
	protected IDeplacable comportementDeplacement = new ResteSurPlace();
	protected IAttaqueBateau comportementAttaque = new AttaquePas();
	
	//private IGroupeDep maFlotte;
	
	
	private IEtat auRepos = new auRepos(this);
	private IEtat enDeplacement = new enDeplacement(this);
	private IEtat enAttaque = new enAttaque(this);
	protected IEtat etatCourant=auRepos;
	
	protected final static Logger LOGGER = Logger.getLogger(AbsBateau.class.getName());

	
	
	public void setPv(int ligne, int colonne, Case pv) {
		this.pv[ligne][colonne] = pv;
	}
	
	public Case getPv(int ligne, int colonne) {
		return pv[ligne][colonne];
	}
	
	public Case[][] getForme(){
		return pv;
	}
	
	public Case getCaseorigine() {
		return caseorigine;
	}
	
	public void setCaseorigine(Case caseorigine) {
		this.caseorigine = caseorigine;
	}

	public void setOrient(Eorientation orient) {
		this.orient = orient;
	}

	public Eorientation getOrient() {
		return orient;
	}
	
	public void setAleatoire() {
		Random rand=new Random();
		int AbcisseAlea=rand.nextInt(10);
		int OrdonneeAlea=rand.nextInt(10);
		int orientalea =rand.nextInt(4);
		this.getCaseorigine().setAbcisse(AbcisseAlea);
		this.getCaseorigine().setOrdonn�e(OrdonneeAlea);
		this.setOrient(Eorientation.values()[orientalea]);
		
	}
	
	
	// fonction principale d'initialisation du bateau
	public void setBateau(int abc,int ord, Eorientation or){
		this.caseorigine.setAbcisse(abc);
		this.caseorigine.setOrdonn�e(ord);
		this.caseorigine.setR�sistance(getLongueur());
		//this.setPlateaujoueur(pl);
		this.setOrient(or);
		

		pv[0][0]=this.caseorigine;
		if(this.orient==Eorientation.BAS) {
			if(this.PositionCorrect()) {
				for (int i = 1; i < pv[0].length; i++) {
					pv[0][i].setAbcisse(this.caseorigine.getAbcisse());
					pv[0][i].setOrdonn�e(this.caseorigine.getOrdonn�e()+i);
					pv[0][i].setR�sistance(this.getLongueur());
				}
				if(pv[1].length>0) {
					for (int i = 0; i < pv[1].length; i++) {
						pv[1][i].setAbcisse(this.caseorigine.getAbcisse()-1);
						pv[1][i].setOrdonn�e(this.caseorigine.getOrdonn�e()+i);	
					}
				}
			}
			else {
				System.out.println("Le placement du bateau est hors limite du plateau");
			}
		}
		else if(this.orient==Eorientation.HAUT) {
			if(this.PositionCorrect()) {
				for (int i = 1; i < pv[0].length; i++) {
					pv[0][i].setAbcisse(this.caseorigine.getAbcisse());
					pv[0][i].setOrdonn�e(this.caseorigine.getOrdonn�e()-i);
					pv[0][i].setR�sistance(this.getLongueur());
				}
				if(pv[1].length>0) {
					for (int i = 0; i < pv[1].length; i++) {
						pv[1][i].setAbcisse(this.caseorigine.getAbcisse()-1);
						pv[1][i].setOrdonn�e(this.caseorigine.getOrdonn�e()+i);
						pv[0][i].setR�sistance(this.getLongueur());
					}
				}
			}
			else {
				System.out.println("Le placement du bateau est hors limite du plateau");
			}
		}
		else if(this.orient==Eorientation.GAUCHE) {
			if(this.PositionCorrect()) {
				for (int i = 1; i < pv[0].length; i++) {
					pv[0][i].setAbcisse(this.caseorigine.getAbcisse()-i);
					pv[0][i].setOrdonn�e(this.caseorigine.getOrdonn�e());
					pv[0][i].setR�sistance(this.getLongueur());
				}
				if(pv[1].length>0) {
					for (int i = 0; i < pv[1].length; i++) {
						pv[1][i].setAbcisse(this.caseorigine.getAbcisse()-i);
						pv[1][i].setOrdonn�e(this.caseorigine.getOrdonn�e()-1);
						pv[0][i].setR�sistance(this.getLongueur());
					}
				}
			}
			else {
				System.out.println("Le placement du bateau est hors limite du plateau");
			}
		}
		else {
			if(this.PositionCorrect()) {
				for (int i = 1; i < pv[0].length; i++) {
					pv[0][i].setAbcisse(this.caseorigine.getAbcisse()+i);
					pv[0][i].setOrdonn�e(this.caseorigine.getOrdonn�e());
					pv[0][i].setR�sistance(this.getLongueur());
				}
				if(pv[1].length>0) {
					for (int i = 0; i < pv[1].length; i++) {
						pv[1][i].setAbcisse(this.caseorigine.getAbcisse()+i);
						pv[1][i].setOrdonn�e(this.caseorigine.getOrdonn�e()+1);
						pv[0][i].setR�sistance(this.getLongueur());
					}
				}
			}
			else {
				System.out.println("Le placement du bateau est hors limite du plateau");
			}
		}
	}
	
	
	/*final public void setMonGroupe(IGroupeDep fl) {
		maFlotte = fl;
	}*/

	/*final public IGroupeDep getMonGroupe() {
		return maFlotte;
	}*/
	
	public IDeplacable getComportementDeplacement() {
		return comportementDeplacement;
	}

	public void setComportementDeplacement(IDeplacable comportementDeplacement) {
		this.comportementDeplacement = comportementDeplacement;
	}

	public IAttaqueBateau getComportementAttaque() {
		return comportementAttaque;
	}

	public void setComportementAttaque(IAttaqueBateau comportementAttaque) {
		this.comportementAttaque = comportementAttaque;
	}
	
	public IEtat getEtatCourant() {
		return etatCourant;
	}

	public void setEtatCourant(IEtat etatCourant) {
		this.etatCourant = etatCourant;
	}

	public IEtat getAuRepos() {
		return auRepos;
	}

	public void setAuRepos(IEtat auRepos) {
		this.auRepos = auRepos;
	}

	public IEtat getEnDeplacement() {
		return enDeplacement;
	}

	public void setEnDeplacement(IEtat enDeplacement) {
		this.enDeplacement = enDeplacement;
	}

	public IEtat getEnAttaque() {
		return enAttaque;
	}

	public void setEnAttaque(IEtat enAttaque) {
		this.enAttaque = enAttaque;
	}

	
	
	 public void arret() { 
		 try { 
			 etatCourant.arret();
			 comportementDeplacement=new ResteSurPlace();
	  } catch (ActionNonPossibleException e) {
		  LOGGER.severe("Ouuppps : pas possible de s'arreter ...");} }
	 
	public void deplacer() {
		 try {
			 etatCourant.deplacer();
		 }catch (ActionNonPossibleException e) {
			  LOGGER.severe("Ouuppps : pas possible de s'arreter ...");
		} 
	 }
	 
	public void avancegauche(int puiss) {
		this.getCaseorigine().setAbcisse(getCaseorigine().getAbcisse()-puiss);
		this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
	}
	
	public void avancedroite(int puiss) {
		this.getCaseorigine().setAbcisse(getCaseorigine().getAbcisse()+puiss);
		this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
	}
	
	public void avancehaut(int puiss) {
		this.getCaseorigine().setOrdonn�e(getCaseorigine().getOrdonn�e()-puiss);
		this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
	}
	
	public void avancebas(int puiss) {
		this.getCaseorigine().setOrdonn�e(getCaseorigine().getOrdonn�e()+puiss);
		this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
	}
	

		
	public void avancer(int puiss){ 
		try {
		//if(DeplacementCorrectavancer(list)) { 
			etatCourant.deplacer();
			comportementDeplacement.avancer(puiss); 
			if(getOrient()==Eorientation.HAUT) {
				avancehaut(puiss);
			} 
			else if(getOrient()==Eorientation.BAS) {
				avancebas(puiss); 
			} 
			else if(getOrient()==Eorientation.GAUCHE) {
				avancegauche(puiss); 
			} 
			else {
				avancedroite(puiss); 
			} 
		//}
			//else { 
			//System.out.println("Le d�placement n'est pas autoris�(i.e chevauchement de bateaux ou hors limite)");
			//}

	} catch (ActionNonPossibleException e) {
		LOGGER.severe("Ouuppps : pas possible de se deplacer ..."); 
		}
	}
		 

	public void rotdroite() {
	//	if (DeplacementCorrectrotdroite(list)) {
		if(getOrient()==Eorientation.HAUT) {
			setOrient(Eorientation.DROITE);
			this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
		}
		else if(getOrient()==Eorientation.BAS) {
				setOrient(Eorientation.GAUCHE);
				this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
		}
		else if(getOrient()==Eorientation.GAUCHE) {
				setOrient(Eorientation.HAUT);
				this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
		}
		else if(getOrient()==Eorientation.DROITE) {
				setOrient(Eorientation.BAS);
				this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
		}
			//else {
				//System.out.println("Le d�placement n'est pas autoris�(i.e chevauchement de bateaux ou hors limite)");
			//}
	}
	
	
	public void rotgauche() {
		//if(DeplacementCorrectrotgauche(list)) {
			if(getOrient()==Eorientation.HAUT) {
				setOrient(Eorientation.GAUCHE);
				this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
			}
			if(getOrient()==Eorientation.BAS) {
				setOrient(Eorientation.DROITE);
				this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//),this.getPlateaujoueur());
			}
			if(getOrient()==Eorientation.GAUCHE) {
				setOrient(Eorientation.BAS);
				this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
			}
			if(getOrient()==Eorientation.DROITE) {
				setOrient(Eorientation.HAUT);
				this.setBateau(caseorigine.getAbcisse(), caseorigine.getOrdonn�e(),this.getOrient());//,this.getPlateaujoueur());
		}
		//else {
	//	System.out.println("Le d�placement n'est pas autoris�(i.e chevauchement de bateaux ou hors limite)");
		//}
	}

	
	public void pivoter(Eorientation orient){
		try {
			etatCourant.deplacer();
			comportementDeplacement.pivoter(orient);
			if (orient==Eorientation.GAUCHE) {
				rotgauche(); 
			}
			else if(orient==Eorientation.DROITE) {
				rotdroite();
			} 
			else {
				System.out.println("oups!! Pas par l�!!!");
				System.out.println("Saisissez une direction � gauche(babord) ou droite(tribord) marin d'eau douce!!" );

			}

		} catch (ActionNonPossibleException e) {
			LOGGER.severe("Ouuppps : pas possible de se deplacer ..."); } }
	
	public void aLAttaque(IAttaquable[] cibles, int puiss) {
		try {
			etatCourant.ALAttaque();
			comportementAttaque.aLAttaque(cibles, puiss);
		} catch (batailleNavaleV1.AutomateBateau.ActionNonPossibleException e) {
			LOGGER.severe("Ouuppps : pas possible de d'attaquer ...");
		}	
	}
		

	public boolean PositionCorrect() {
		if ((this.orient==Eorientation.GAUCHE)&&((this.caseorigine.getAbcisse()-getLongueur())<0 )){
				return false;
		}
		else if((orient==Eorientation.DROITE)&&((caseorigine.getAbcisse()+ getLongueur())>9 )) {
			return false;
		}
		else if((orient==Eorientation.HAUT)&&((caseorigine.getOrdonn�e()-getLongueur())<0 )) {
			return false;
		}
		else if((orient==Eorientation.BAS)&&((caseorigine.getOrdonn�e()+getLongueur())>9)){
			return false;
		}
		else {
			return true;
			
		}
}
	public Case findCasePV(int abc, int ord) {
		Case c=new Case();
		c.setR�sistance(-1);
		for (int i = 0; i < pv[0].length; i++) {
			if((pv[0][i].getAbcisse()==abc)&&(pv[0][i].getOrdonn�e()==ord)){
				 c=pv[0][i];
			}
		}
		if(pv[1].length>0) {
			for(int i=0; i<pv[1].length; i++) {
				if((pv[1][i].getAbcisse()==abc)&&(pv[1][i].getOrdonn�e()==ord)) {
					c=pv[1][i];
				}
			}
		}
		return c;
	}
	
	public boolean estDetruit() {
		boolean state=true;
		for (int i = 0; i < pv[0].length; i++) {
			if(pv[0][i].getR�sistance()!=0) {
				state=false;
			}
		}
		if(pv[1].length>0) {
			for (int i = 0; i < pv[1].length; i++) {
				if(pv[1][i].getR�sistance()!=0) {
					state=false;
				}
			}
		}
		return state;
	}
	public int PuissancedeFeu() {
		int puiss=0;
		for (int i = 0; i < pv[0].length; i++) {
			if(pv[0][i].getR�sistance()==this.getLongueur()) {
				puiss++;
			}
		}
		if(pv[1].length>0) {
			for (int i = 0; i < pv[1].length; i++) {
				if(pv[1][i].getR�sistance()==this.getLongueur()) {
					puiss++;
				}
			}
		}
		if(puiss>this.getLongueur()) {
			puiss=this.getLongueur();
		}
		return puiss;
	}
	public int maxres() {
		int max=0;
		for (int i = 0; i < pv[0].length; i++) {
			if(pv[0][i].getR�sistance()>max) {
				max=pv[0][i].getR�sistance();
			}
		}
		if(pv[1].length>0) {
			for (int i = 0; i < pv[1].length; i++) {
				if(pv[1][i].getR�sistance()>max) {
					max=pv[1][i].getR�sistance();
				}
			}
		}
		return max;
	}
	

	public void upgradepv() {
		for (int i = 0; i < pv[0].length; i++) {
			pv[0][i].setR�sistance(pv[0][i].getR�sistance()+1);
		}
		if(pv[1].length>0) {
			for (int i = 0; i < pv[1].length; i++) {
				pv[1][i].setR�sistance(pv[1][i].getR�sistance()+1);
			}
		}
	}


	

}

