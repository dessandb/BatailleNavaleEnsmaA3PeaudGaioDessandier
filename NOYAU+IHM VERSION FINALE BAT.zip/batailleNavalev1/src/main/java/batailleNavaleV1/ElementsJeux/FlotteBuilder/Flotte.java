package batailleNavaleV1.ElementsJeux.FlotteBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import batailleNavaleV1.ElementsJeux.Bateaux.Eelementjeu;
import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;
import batailleNavaleV1.ElementsJeux.Factory.AbsFactory;
import batailleNavaleV1.plateauJeu.Case;
import batailleNavaleV1.plateauJeu.plateau;

public class Flotte  {
	
	private Map<Eelementjeu,IBateau> flotte ; 
	private plateau PlateauJoueur;
	
	public Flotte(plateau plat) {
		flotte = new HashMap<Eelementjeu, IBateau>() ;
		PlateauJoueur=plat;
	}
	
	public ArrayList<Eelementjeu> listboats(){
		ArrayList<Eelementjeu> listeBateaux= new ArrayList<Eelementjeu>();
		for (int i = 0; i < Eelementjeu.values().length; i++) {
			listeBateaux.add(Eelementjeu.values()[i]);
		}
		return listeBateaux;
	}
	
	public void createFlotte() {
		ArrayList<Eelementjeu> listeBateaux=this.listboats();
		for (Eelementjeu bateau : listeBateaux) {
			flotte.put(bateau, AbsFactory.createFactory(bateau).createBateau());
		}
	}

	public Map<Eelementjeu, IBateau> getFlotte() {
		return flotte;
	}
	
	public IBateau getBateau(Eelementjeu bateau) {
		return flotte.get(bateau);
	}

	public plateau getPlateauJoueur() {
		return PlateauJoueur;
	}

	public void setPlateauJoueur(plateau plateauJoueur) {
		PlateauJoueur = plateauJoueur;
	}
	public IBateau getBateauCase(int abc, int ord) {
		Case c=PlateauJoueur.findCase(abc, ord);
		IBateau result=null;
			ArrayList<Eelementjeu> listeenum=this.listboats();
			ArrayList<IBateau> listeBateaux= new ArrayList<IBateau>(); 
			for (Eelementjeu bateau : listeenum) {
				listeBateaux.add(this.getBateau(bateau));
			}
			for (IBateau boat: listeBateaux) {
				Case found=boat.findCasePV(abc, ord);
				if(found.getR�sistance()>0) {
					result=boat;
				}
			}
		return result;
	}
	
}
