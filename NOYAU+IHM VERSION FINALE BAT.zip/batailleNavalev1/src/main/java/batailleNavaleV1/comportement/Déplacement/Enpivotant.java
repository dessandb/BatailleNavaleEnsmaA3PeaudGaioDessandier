package batailleNavaleV1.comportement.D�placement;
import java.util.logging.Logger;

import batailleNavaleV1.ElementsJeux.Bateaux.Eorientation;


public class Enpivotant implements IDeplacable {
private final static Logger LOGGER = Logger.getLogger(Enpivotant.class.getName());
	
	public void pivoter(Eorientation orient) {
		tourne();
	}
	
	private void tourne() {
		LOGGER.info(": cap babord ou tribord ");
	}
	
	public void avancer(int distance) {
		// TODO Auto-generated method stub
		
	}

}
