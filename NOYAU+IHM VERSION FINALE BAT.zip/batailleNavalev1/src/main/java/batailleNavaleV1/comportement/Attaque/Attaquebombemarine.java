package batailleNavaleV1.comportement.Attaque;
import java.util.logging.Logger;

public class Attaquebombemarine implements IAttaqueBombe {
	private final static Logger LOGGER = Logger.getLogger(Attaquebombemarine.class.getName()); 

	public void explobombe(IAttaquable[]cibles) {
		explosionbombe();
		cibles[0].estAttaque(3);
		for (int i = 1; i < 9; i++) {
			if(cibles[i]!=null) {
			cibles[i].estAttaque(2);
		}
		}
		for (int i=9;i<cibles.length;i++) {
			if(cibles[i]!=null) {
			cibles[i].estAttaque(1);
		}
		}
	}
	
	private void explosionbombe() {
		LOGGER.info(" TNT I'm dynamite, watch me explodeeee !!!");
	}


}


