package batailleNavaleV1.comportement.Attaque;

public interface IAttaqueSousMarin {

	int[] eclaireTout(IEclairable[] list,int res);
}
