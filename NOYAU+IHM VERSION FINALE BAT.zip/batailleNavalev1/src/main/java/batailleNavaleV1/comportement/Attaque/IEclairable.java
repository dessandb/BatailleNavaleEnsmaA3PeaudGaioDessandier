package batailleNavaleV1.comportement.Attaque;

public interface IEclairable {
	int estEclairee();
}
