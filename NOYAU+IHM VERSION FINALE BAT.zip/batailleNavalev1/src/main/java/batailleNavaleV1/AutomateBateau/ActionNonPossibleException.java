package batailleNavaleV1.AutomateBateau;

public class ActionNonPossibleException extends Exception {

	private static final long serialVersionUID = 1L;
}
