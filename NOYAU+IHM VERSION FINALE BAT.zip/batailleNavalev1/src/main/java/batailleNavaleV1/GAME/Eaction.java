package batailleNavaleV1.GAME;

public enum Eaction {
	DEBUT_TOUR,ATTAQUER,ATTAQUEENCROIX,DEPLACER,FUSEE,SKIP,END_TOUR
}
