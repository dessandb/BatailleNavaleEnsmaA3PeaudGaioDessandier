package Tests;

import IHM.Scenes.Scene1.PresentationScene1;
import IHM.Scenes.Scene1.VueScene1;
import IHM.Scenes.Scene2.PresentationScene2;
import IHM.Scenes.Scene2.VueScene2;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class TestScene1 extends Application{

	@Override
	public void start(Stage primaryStage) throws Exception {
		try {

			PresentationScene2 prezInit = new PresentationScene2(10, 10, new StackPane());
			VueScene2 vueInit  = new VueScene2(prezInit);
			prezInit.setVueScene2(vueInit);
			
			StackPane st = new StackPane();
			
			PresentationScene1 prezTest = new PresentationScene1(vueInit,prezInit,st);
			VueScene1 vueScene1 = new VueScene1(prezTest) ;
			prezTest.setVueScene1(vueScene1);
			st.getChildren().addAll(vueScene1);
			prezTest.setSt(st);
			
			Scene scene = new Scene(prezTest.getSt(),400,400);
			primaryStage.setTitle("TEST SCENE 1");
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setMinHeight(800);
			primaryStage.setMinWidth(800);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}

}
