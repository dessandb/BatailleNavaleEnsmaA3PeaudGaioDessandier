package Tests;

import IHM.AgentPlateau.agentCase.PresentationAgentCase;
import IHM.AgentPlateau.agentCase.VueAgentCase;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class TestAgentCase extends Application{

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		try {
			FlowPane flow = new FlowPane();
			PresentationAgentCase prezCase = new PresentationAgentCase(true);
			PresentationAgentCase prezCase2 = new PresentationAgentCase(false);
			VueAgentCase vueCase = new VueAgentCase(prezCase, 150);
			VueAgentCase vueCase2 = new VueAgentCase(prezCase2, 50);
			prezCase.setVue(vueCase);
			prezCase2.setVue(vueCase2);
			flow.getChildren().addAll(vueCase,vueCase2);
			Scene scene = new Scene(flow,400,400);
			primaryStage.setTitle("TEST_CASE");
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setMinHeight(800);
			primaryStage.setMinWidth(800);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
