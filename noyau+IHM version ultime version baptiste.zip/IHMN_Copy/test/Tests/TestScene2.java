package Tests;

import IHM.Scenes.Scene2.PresentationScene2;
import IHM.Scenes.Scene2.VueScene2;
import IHM.Scenes.Scene3.PresentationScene3_Joueur1;
import IHM.Scenes.Scene3.VueScene3_Joueur1;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class TestScene2 extends Application{

	public static void main(String[] args) {
		launch(args);
	}
 
	@Override
	public void start(Stage primaryStage) throws Exception {
			try {

				
				PresentationScene3_Joueur1 prezIHM = new PresentationScene3_Joueur1(10, 10, new StackPane());
				VueScene3_Joueur1 vueIHM = new VueScene3_Joueur1(prezIHM);
				prezIHM.setVuePartie(vueIHM);
				
				StackPane st=new StackPane();
				
				PresentationScene2 prezInit = new PresentationScene2(10, 15,st);
				VueScene2 vueInit = new VueScene2(prezInit);
				prezInit.setVueScene2(vueInit);
				//st.getChildren().addAll(vueInit);
				prezInit.setSt(st);
				//flow.getChildren().addAll(vueInit);
				Scene scene = new Scene(prezInit.getSt(),400,400);
				primaryStage.setTitle("TEST_SCENE_2");
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStage.setScene(scene);
				primaryStage.setMinHeight(800);
				primaryStage.setMinWidth(800);
				primaryStage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}

	}
