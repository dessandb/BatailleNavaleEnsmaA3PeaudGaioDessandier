package IHM.ComposantsGraphiques.AgentComboBox;

public interface IVueComboBox {
	public void notifOption(final int choix);
	public void notifEnable(Boolean enab);
}
