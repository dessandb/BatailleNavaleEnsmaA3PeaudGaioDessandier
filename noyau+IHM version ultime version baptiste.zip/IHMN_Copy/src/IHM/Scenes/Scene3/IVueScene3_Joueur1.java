package IHM.Scenes.Scene3;

public interface IVueScene3_Joueur1 {
	void createBoutonAccord(String msg, int i);
	void choixBoutonRetour(int i);
}
