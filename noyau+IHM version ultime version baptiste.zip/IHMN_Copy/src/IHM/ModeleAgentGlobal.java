package IHM;

public class ModeleAgentGlobal {

}
