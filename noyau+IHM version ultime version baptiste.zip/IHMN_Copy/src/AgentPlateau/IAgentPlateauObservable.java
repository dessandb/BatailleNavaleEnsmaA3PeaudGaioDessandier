package AgentPlateau;

public interface IAgentPlateauObservable {
	public void notifyAgentPlateau(int i);
}
