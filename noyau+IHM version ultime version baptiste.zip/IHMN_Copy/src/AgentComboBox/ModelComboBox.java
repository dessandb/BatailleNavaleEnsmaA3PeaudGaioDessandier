package AgentComboBox;

public class ModelComboBox {

	private int choixConversionIndex;
	
	public ModelComboBox() {
		choixConversionIndex = 0;
	}
	
	public int getValChamp() {return choixConversionIndex;}
	public void setValChamp(final int c) {choixConversionIndex = c;}
	
}
