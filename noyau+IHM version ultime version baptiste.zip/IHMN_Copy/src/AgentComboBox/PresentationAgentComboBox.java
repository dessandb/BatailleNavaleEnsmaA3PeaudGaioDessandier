package AgentComboBox;

import java.util.ArrayList;

public class PresentationAgentComboBox {

	private ModelComboBox mod;
	private IVueComboBox vue;

	private Boolean enableBox;
	
	private Boolean valueCB;
	
	private ArrayList<IAgentComboBoxObservable> observateurs;
	
	public PresentationAgentComboBox(boolean en,boolean cb) {
		valueCB=cb;
		enableBox = en;
		observateurs = new ArrayList<IAgentComboBoxObservable>();
		mod = new ModelComboBox();
	}
	
	public Boolean getValueCB() {
		return valueCB;
	}

	public void setValueCB(Boolean valueCB) {
		this.valueCB = valueCB;
	}

	public void setVue(IVueComboBox v) {
		vue = v;
		vue.notifEnable(enableBox);
	}
	
	public int getVal() {
		return mod.getValChamp();
	}
	
	public void choisirChoix(int choix) {
		mod.setValChamp(choix);
		vue.notifOption(choix);
	}
	
	public void notifyAgents() {
		for (IAgentComboBoxObservable agent : observateurs) {
			agent.notifyComboBoxAgents();
		}
	}
	
	public void ajouterObservateur(IAgentComboBoxObservable obs) {
		observateurs.add(obs);
	}
	
	public void enleverObservateur(IAgentComboBoxObservable obs) {
		if(observateurs.contains(obs)) {
			observateurs.remove(obs);
		}
	}	
}
