package Scene1;

public interface IVueScene1 {
	public void setPrezScene1(PresentationScene1 prezScene1);
}
