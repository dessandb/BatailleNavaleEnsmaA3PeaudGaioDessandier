package Scene1;

public interface IObservateurScene1 {
	public void notifyAgentScene1();
}
