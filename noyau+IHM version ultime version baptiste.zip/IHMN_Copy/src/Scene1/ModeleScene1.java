package Scene1;

public class ModeleScene1 {

}
