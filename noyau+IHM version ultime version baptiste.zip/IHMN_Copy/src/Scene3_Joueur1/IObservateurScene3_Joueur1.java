package Scene3_Joueur1;

public interface IObservateurScene3_Joueur1 {
	public void notifyScene3();
}
