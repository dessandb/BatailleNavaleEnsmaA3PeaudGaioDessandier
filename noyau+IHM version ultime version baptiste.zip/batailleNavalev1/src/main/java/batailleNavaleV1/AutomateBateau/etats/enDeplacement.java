package batailleNavaleV1.AutomateBateau.etats;

import batailleNavaleV1.AutomateBateau.ActionNonPossibleException;
import batailleNavaleV1.AutomateBateau.IGestionEtat;

public class enDeplacement extends AbstractEtat {
	public enDeplacement(IGestionEtat aut) {
		super(aut);
	}
	
	@Override
	public void arret() throws ActionNonPossibleException {
		autom.setEtatCourant(autom.getAuRepos());
	}

	@Override
	public void ALAttaque() throws ActionNonPossibleException {
		autom.setEtatCourant(autom.getEnAttaque());
	}
}
