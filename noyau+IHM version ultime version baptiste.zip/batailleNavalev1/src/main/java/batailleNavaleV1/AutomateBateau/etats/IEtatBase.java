package batailleNavaleV1.AutomateBateau.etats;
import batailleNavaleV1.AutomateBateau.ActionNonPossibleException;
public interface IEtatBase {
	public void arret() throws ActionNonPossibleException;
	public void deplacer() throws ActionNonPossibleException;
}
