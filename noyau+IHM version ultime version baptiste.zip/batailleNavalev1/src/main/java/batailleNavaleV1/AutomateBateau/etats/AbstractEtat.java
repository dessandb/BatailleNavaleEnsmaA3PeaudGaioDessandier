package batailleNavaleV1.AutomateBateau.etats;

import batailleNavaleV1.AutomateBateau.ActionNonPossibleException;
import batailleNavaleV1.AutomateBateau.IGestionEtat;

public abstract class AbstractEtat implements IEtat {

	protected IGestionEtat autom;

	public AbstractEtat(IGestionEtat aut) {
		autom = aut;
	}
	

	public void arret() throws ActionNonPossibleException {
		throw new ActionNonPossibleException();
	}


	public void deplacer() throws ActionNonPossibleException {
		throw new ActionNonPossibleException();		
	}


	public void ALAttaque() throws ActionNonPossibleException {
		throw new ActionNonPossibleException();		
	}

}
