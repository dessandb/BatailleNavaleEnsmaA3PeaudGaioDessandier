package batailleNavaleV1.AutomateBateau;

import batailleNavaleV1.AutomateBateau.etats.IEtat;

public interface IGestionEtat {

	public void setEtatCourant(IEtat et);
	public IEtat getAuRepos();
	public IEtat getEnAttaque();
	public IEtat getEnDeplacement();
}
