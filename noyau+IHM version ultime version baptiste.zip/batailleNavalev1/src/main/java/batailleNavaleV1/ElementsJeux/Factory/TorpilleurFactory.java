package batailleNavaleV1.ElementsJeux.Factory;

import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;
import batailleNavaleV1.ElementsJeux.Bateaux.Torpilleur;

public class TorpilleurFactory extends AbsFactory{

	@Override
	public IBateau createBateau() {
		return new Torpilleur();
	}

}
