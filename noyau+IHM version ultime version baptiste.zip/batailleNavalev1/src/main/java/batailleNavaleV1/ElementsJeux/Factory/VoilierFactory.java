package batailleNavaleV1.ElementsJeux.Factory;

import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;
import batailleNavaleV1.ElementsJeux.Bateaux.Voilier;

public class VoilierFactory extends AbsFactory{

	@Override
	public IBateau createBateau() {
		return new Voilier();
	}

}
