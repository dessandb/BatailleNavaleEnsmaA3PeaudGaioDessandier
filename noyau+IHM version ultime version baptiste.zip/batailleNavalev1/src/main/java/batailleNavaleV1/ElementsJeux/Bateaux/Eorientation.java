package batailleNavaleV1.ElementsJeux.Bateaux;

public enum Eorientation {

	GAUCHE,DROITE,HAUT,BAS
}
