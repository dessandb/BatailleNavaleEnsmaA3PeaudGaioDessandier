package batailleNavaleV1.ElementsJeux.Bateaux;

import java.util.logging.Logger;

import batailleNavaleV1.comportement.Attaque.Attaqueclassique;
import batailleNavaleV1.comportement.Attaque.Attaqueencroix;
import batailleNavaleV1.comportement.Attaque.IEclairable;
import batailleNavaleV1.comportement.D�placement.Enavancant;
import batailleNavaleV1.comportement.D�placement.Enpivotant;
import batailleNavaleV1.plateauJeu.Case;

public class PorteAvionClassic  extends AbsBateau {
	
	private static final int longueur = 5;
	private static final int nbLignes = 1;
	private final static Logger LOGGER = Logger.getLogger(PorteAvionClassic.class.getName());
	public PorteAvionClassic() {
		pv = new Case[nbLignes-1][longueur-1];
		for(int i=0 ; i<longueur ; i++) {
			pv[0][i]=new Case();
			pv[0][i].setR�sistance(longueur);
		}
		comportementAttaque= new Attaqueclassique();
		comportementDeplacement=new Enpivotant();
	}

	
	public int getLongueur() {
		return longueur;
	}

	public static int getNblignes() {
		return nbLignes;
	}


	public int[] eclaireTout(IEclairable[] cibles) {
		return null;
		// TODO Auto-generated method stub
		
	}
}