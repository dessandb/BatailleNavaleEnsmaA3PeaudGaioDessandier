package batailleNavaleV1.ElementsJeux.Bateaux;

import java.util.logging.Logger;

import batailleNavaleV1.comportement.Attaque.Attaqueclassique;
import batailleNavaleV1.comportement.Attaque.Attaquefuseeeclairante;
import batailleNavaleV1.comportement.Attaque.IAttaqueSousMarin;
import batailleNavaleV1.comportement.Attaque.IEclairable;
import batailleNavaleV1.comportement.D�placement.Enpivotant;
import batailleNavaleV1.plateauJeu.Case;

public class SousMarin extends AbsBateau implements IAttaqueSousMarin,ISousMarin {
	
	private static final int longueur = 3;
	private static final int nbLignes = 1;
	private final static Logger LOGGER = Logger.getLogger(SousMarin.class.getName());
	protected IAttaqueSousMarin fusee = new Attaquefuseeeclairante();

	public SousMarin() {
		pv = new Case[nbLignes-1][longueur-1];
		for(int i=0 ; i<longueur ; i++) {
			pv[0][i]=new Case();
			pv[0][i].setR�sistance(longueur);
		}
		comportementAttaque= new Attaqueclassique();
		comportementDeplacement=new Enpivotant();
	}

	
	public int getLongueur() {
		return longueur;
	}

	public static int getNblignes() {
		return nbLignes;
	}
	

public int[] eclaireTout(IEclairable[] cibles,int res) {
	try {
		etatCourant.ALAttaque();
		
	} catch (batailleNavaleV1.AutomateBateau.ActionNonPossibleException e) {
		LOGGER.severe("Ouuppps : pas possible de d'attaquer ...");
	}
	return fusee.eclaireTout(cibles,res);
	
}

	

public int[] eclaireTout(IEclairable[] cibles) {
	try {
		etatCourant.ALAttaque();
		
	} catch (batailleNavaleV1.AutomateBateau.ActionNonPossibleException e) {
		LOGGER.severe("Ouuppps : pas possible de d'attaquer ...");
	}
	return fusee.eclaireTout(cibles,this.maxres());
}
}


	
	
