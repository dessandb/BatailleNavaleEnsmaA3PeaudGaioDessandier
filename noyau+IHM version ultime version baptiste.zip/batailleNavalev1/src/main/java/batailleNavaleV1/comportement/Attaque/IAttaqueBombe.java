package batailleNavaleV1.comportement.Attaque;

public interface IAttaqueBombe {
	public void explobombe(IAttaquable[] cibles);
}
