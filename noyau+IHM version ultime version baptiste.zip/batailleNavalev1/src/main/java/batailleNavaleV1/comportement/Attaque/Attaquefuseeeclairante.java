package batailleNavaleV1.comportement.Attaque;
import java.util.logging.Logger;

public class Attaquefuseeeclairante implements IAttaqueSousMarin {

	private final static Logger LOGGER = Logger.getLogger(AttaquePas.class.getName());

	public int[] eclaireTout(IEclairable[] list,int res) {
		fusee();
		int[] result= new int[list.length-1];
		for (int i = 0; i < list.length; i++) {
			if(list[i]!=null) {
			result[i]=list[i].estEclairee();
		}
			else {
				result[i]=-1;
			}
		}
		return result;
		
	}

	
	private void fusee() {
		LOGGER.severe(" mais o� peuvent ils bien �tre? !!!");
	}

}
