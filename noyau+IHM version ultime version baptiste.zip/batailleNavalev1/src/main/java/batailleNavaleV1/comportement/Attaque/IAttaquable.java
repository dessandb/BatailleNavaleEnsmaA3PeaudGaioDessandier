package batailleNavaleV1.comportement.Attaque;

public interface IAttaquable {

	public void estAttaque(final int puiss)throws NullPointerException;
	
}
