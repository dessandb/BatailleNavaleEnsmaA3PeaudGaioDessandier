package batailleNavaleV1.comportement.Attaque;

public interface IAttaqueBateau {

	void aLAttaque(IAttaquable[] cibles, final int puiss);



}
