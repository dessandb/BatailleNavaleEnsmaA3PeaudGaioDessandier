package batailleNavaleV1.comportement.D�placement;

import batailleNavaleV1.ElementsJeux.Bateaux.Eorientation;

public interface IDeplacable {

	void pivoter(Eorientation orient);
	void avancer(int distance);
}
