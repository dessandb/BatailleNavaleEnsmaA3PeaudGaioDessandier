package batailleNavaleV1.GAME;

import java.util.Random;

import batailleNavaleV1.ElementsJeux.Bateaux.Eelementjeu;
import batailleNavaleV1.ElementsJeux.Bateaux.Eorientation;
import batailleNavaleV1.comportement.Attaque.Attaqueclassique;
import batailleNavaleV1.comportement.Attaque.Attaqueencroix;
import batailleNavaleV1.comportement.Attaque.IAttaqueBateau;
import batailleNavaleV1.comportement.D�placement.IDeplacable;

public class JoueurIA extends Joueur {

	public JoueurIA(String n) {
		super(n);
		setFlottealea();
	}
	public void setFlottealea() {
		for(int i=0;i<7;i++) {
			Random rand=new Random();
			int abcalea=rand.nextInt(10);
			int ordalea=rand.nextInt(10);
			int orientalea=rand.nextInt(4);
			if(this.putBateauPlateau(Eelementjeu.values()[i], abcalea, ordalea, Eorientation.values()[orientalea])) {
				
			}
			else{
				setFlottealea();
			}
		}
	}
	public void ActionAleatoire(Joueur j) {
		Random rand=new Random();
		int choixalea=rand.nextInt(3);
		switch(choixalea) {
		case 0:
			int bateaualea=rand.nextInt(7);
			int abcalea=rand.nextInt(10);
			int ordalea=rand.nextInt(10);
			int comportAttqalea=rand.nextInt(2);
			IAttaqueBateau comportAttq;
			if (comportAttqalea==0) {
				 comportAttq=new Attaqueclassique();
			}
			else {
				 comportAttq=new Attaqueencroix();
			}
			
			this.attaquer(Eelementjeu.values()[bateaualea], abcalea, ordalea, j.getPlateaujoueur(), comportAttq);
		case 1:
			int bateaualea2=rand.nextInt(7);
			int dist=rand.nextInt();
			int orientalea=rand.nextInt(2);
			int comportDepalea=rand.nextInt(2);
			if (comportDepalea==0) {
				this.move(Eelementjeu.values()[bateaualea2], dist);
			}
			else {
				this.move(Eelementjeu.values()[bateaualea2], Eorientation.values()[orientalea]);
			}
		case 2:
			int abcalea2=rand.nextInt(10);
			int ordalea2=rand.nextInt(10);
			this.attaquerfusee(Eelementjeu.SOUS_MARIN, abcalea2, ordalea2, j.getFlottejoueur());
		}
		
	}
	
	
}
