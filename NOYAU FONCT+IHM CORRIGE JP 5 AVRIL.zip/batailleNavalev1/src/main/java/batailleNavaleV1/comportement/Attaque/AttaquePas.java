package batailleNavaleV1.comportement.Attaque;

import java.util.logging.Logger;


public class AttaquePas implements IAttaqueBateau {
private final static Logger LOGGER = Logger.getLogger(AttaquePas.class.getName());

	public void aLAttaque(IAttaquable[] cibles, int puiss) {
		AttaquePasDuTout();
		
	}
	
	
	private void AttaquePasDuTout() {
		LOGGER.severe(" Mode chill confinement coronavirus ma men !!!");
	}

	

	public void eclaireTout(IAttaquable[] cibles) {
		// TODO Auto-generated method stub
		
	}
}


