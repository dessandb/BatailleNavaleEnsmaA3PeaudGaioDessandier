package batailleNavaleV1.comportement.Attaque;
import java.util.logging.Logger;


public class Attaqueencroix implements IAttaqueBateau {
	private final static Logger LOGGER = Logger.getLogger(Attaqueencroix.class.getName()); 
	
	public void aLAttaque(IAttaquable[] cibles, int puiss) {
		Tirencroix();
		for (int i = 0; i < cibles.length; i++) {
			if(cibles[i]!=null) {
			cibles[i].estAttaque(puiss);
		}
		}
		
	}
	
	private void Tirencroix() {
		LOGGER.info(" Par la sacro-sainte croix de J�sus !!!");
	}

	public void eclaireTout(IAttaquable[] cibles) {
		// TODO Auto-generated method stub
		
	}
}

