package batailleNavaleV1.comportement.D�placement;
import java.util.logging.Logger;

import batailleNavaleV1.ElementsJeux.Bateaux.Eorientation;
import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;



public class Enavancant implements IDeplacable {
private final static Logger LOGGER = Logger.getLogger(Enavancant.class.getName());


	public void avancer(int distance) {
		go();
		
	}
	
	protected void go() {
		LOGGER.info(": Pleine machine avant");
		
		
	}

	public void pivoter(Eorientation orient) {
		// TODO Auto-generated method stub
		
	}
}
