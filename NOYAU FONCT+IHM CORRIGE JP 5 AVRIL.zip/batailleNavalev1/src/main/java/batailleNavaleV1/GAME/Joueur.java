package batailleNavaleV1.GAME;

import batailleNavaleV1.ElementsJeux.Bateaux.Eelementjeu;
import batailleNavaleV1.ElementsJeux.Bateaux.Eorientation;
import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;
import batailleNavaleV1.ElementsJeux.FlotteBuilder.Flotte;
import batailleNavaleV1.comportement.Attaque.Attaqueclassique;
import batailleNavaleV1.comportement.Attaque.Attaqueencroix;
import batailleNavaleV1.comportement.Attaque.IAttaquable;
import batailleNavaleV1.comportement.Attaque.IAttaqueBateau;
import batailleNavaleV1.comportement.Attaque.IEclairable;
import batailleNavaleV1.comportement.D�placement.Enavancant;
import batailleNavaleV1.comportement.D�placement.Enpivotant;
import batailleNavaleV1.comportement.D�placement.IDeplacable;
import batailleNavaleV1.plateauJeu.Case;
import batailleNavaleV1.plateauJeu.plateau;

public class Joueur {
	private String name;
	private Eaction Tourjoueur=Eaction.DEBUT_TOUR;
	private plateau Plateaujoueur = new plateau();
	private Flotte flottejoueur = new Flotte(Plateaujoueur);
	private int missattaq=0;
	private int successattaq=0;
	private boolean upgradeattq=false;
	
	public Joueur(String n) {
		this.name=n;
		flottejoueur.createFlotte();
		//Avoir les deux voiliers si m�me nom sous Eelement jeu
		IBateau voilier_un=flottejoueur.getBateau(Eelementjeu.VOILIER1);
		voilier_un.setAleatoire();
		IBateau voilier_deux=flottejoueur.getBateau(Eelementjeu.VOILIER2);
		voilier_deux.setAleatoire();
	}
	
	public Flotte getFlottejoueur() {
		return flottejoueur;
	}

	public boolean putBateauPlateau(Eelementjeu el, int abc, int ord, Eorientation or) {
		boolean ok=false;
		if((el==Eelementjeu.VOILIER1)||(el==Eelementjeu.VOILIER2)) {
			System.out.println("Non vous ne pouvez pas placer les voiliers");
			ok=false;
		}
		else {
			IBateau bateau= flottejoueur.getBateau(el);
			bateau.setBateau(abc, ord, or);
			for (int i = 0; i < bateau.getForme()[0].length; i++) {
				if (Plateaujoueur.estOccupee(bateau.getForme()[0][i].getAbcisse(),bateau.getForme()[0][i].getOrdonn�e())==false){
					Plateaujoueur.placerBateauplateau(bateau.getForme());
					ok=true;
				}
				else {
					System.out.println("Les coordonn�es saisies ou l'orientation de"+ el +"ne sont pas valides pour placer le bateau");
					ok=false;
				}
			}	
		}
		return ok;
	}
	
	public void attaquer(Eelementjeu el, int abc, int ord, plateau pl,IAttaqueBateau comportAttq) {
		if((el==Eelementjeu.VOILIER1)||(el==Eelementjeu.VOILIER2)) {
			System.out.println("Non vous ne pouvez pas attaquer avec les voiliers");
		}
		else {
			IBateau bateau= flottejoueur.getBateau(el);
			bateau.setComportementAttaque(comportAttq);
			if(bateau.getComportementAttaque()== new Attaqueclassique()) {
				this.setTourjoueur(Eaction.ATTAQUER);
				Case c=pl.findCase(abc, ord);
				if(c.getR�sistance()==0) {
					this.missattaq++;
				}
				else {
					this.successattaq++;
				}
				IAttaquable[] cibles= {c};
				if(upgradeattq) {
					bateau.aLAttaque(cibles, bateau.PuissancedeFeu()+2);
					this.upgradeattq=false;
				}
				else {
				bateau.aLAttaque(cibles, bateau.PuissancedeFeu());
				}
			}
			if(bateau.getComportementAttaque()== new Attaqueencroix()) {
				this.setTourjoueur(Eaction.ATTAQUEENCROIX);
				Case c=pl.findCase(abc, ord);
				Case[] list=pl.Encroix(c);
				boolean b=succeed(list);
				if(b) {
					this.successattaq++;
				}
				else {
					this.missattaq++;
				}
				IAttaquable[] cibles= pl.Encroix(c);
				if(upgradeattq) {
					bateau.aLAttaque(cibles, bateau.PuissancedeFeu()+2);
					this.upgradeattq=false;
				}
				else {
				bateau.aLAttaque(cibles, bateau.PuissancedeFeu());
				}
				
			}
		}
		this.finTour();
	}
	public int getMissattaq() {
		return missattaq;
	}

	public void setMissattaq(int missattaq) {
		this.missattaq = missattaq;
	}

	public int getSuccessattaq() {
		return successattaq;
	}

	public void setSuccessattaq(int successattaq) {
		this.successattaq = successattaq;
	}

	public boolean succeed(Case[] list) {
		int compteurnonnul=0;
		for (int i = 0; i < list.length; i++) {
			if(list[i].getR�sistance()>0) {
				compteurnonnul++;
			}
		}
		if(compteurnonnul>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Eaction getTourjoueur() {
		return Tourjoueur;
	}

	public void setTourjoueur(Eaction tourjoueur) {
		Tourjoueur = tourjoueur;
	}

	public void move(Eelementjeu el, int dist, Eorientation or ) {
		this.setTourjoueur(Eaction.DEPLACER);
		if((el==Eelementjeu.VOILIER1)||(el==Eelementjeu.VOILIER2)) {
			System.out.println("Non vous ne pouvez pas d�placer les voiliers");
		}
		else {
		IBateau bateau= flottejoueur.getBateau(el);
		IDeplacable comportementDep=bateau.getComportementDeplacement();
		if(comportementDep==new Enavancant() ) {
			Plateaujoueur.enleverBateauplateau(bateau.getForme());
			bateau.avancer(dist);
			Plateaujoueur.placerBateauplateau(bateau.getForme());
		}
		else if(comportementDep==new Enpivotant()) {
			Plateaujoueur.enleverBateauplateau(bateau.getForme());
			bateau.pivoter(or);
			Plateaujoueur.placerBateauplateau(bateau.getForme());
		}
		
		}
		this.finTour();
	}
	
	public void move(Eelementjeu el, int dist) {
		this.setTourjoueur(Eaction.DEPLACER);
		if((el==Eelementjeu.VOILIER1)||(el==Eelementjeu.VOILIER2)) {
			System.out.println("Non vous ne pouvez pas d�placer les voiliers");
		}
		else {
		IBateau bateau= flottejoueur.getBateau(el);
		IDeplacable comportementDep=bateau.getComportementDeplacement();
		if(comportementDep==new Enavancant() ) {
			Plateaujoueur.enleverBateauplateau(bateau.getForme());
			bateau.avancer(dist);
			Plateaujoueur.placerBateauplateau(bateau.getForme());
		}
		else if(comportementDep==new Enpivotant()) {
			Plateaujoueur.enleverBateauplateau(bateau.getForme());
			bateau.pivoter(Eorientation.HAUT);
			Plateaujoueur.placerBateauplateau(bateau.getForme());
		}
		}
		this.finTour();
	}
	public void move(Eelementjeu el, Eorientation or) {
		this.setTourjoueur(Eaction.DEPLACER);
		if((el==Eelementjeu.VOILIER1)||(el==Eelementjeu.VOILIER2)) {
			System.out.println("Non vous ne pouvez pas d�placer les voiliers");
		}
		else {
		IBateau bateau= flottejoueur.getBateau(el);
		IDeplacable comportementDep=bateau.getComportementDeplacement();
		if(comportementDep==new Enavancant() ) {
			Plateaujoueur.enleverBateauplateau(bateau.getForme());
			bateau.avancer(0);
			Plateaujoueur.placerBateauplateau(bateau.getForme());
		}
		else if(comportementDep==new Enpivotant()) {
			Plateaujoueur.enleverBateauplateau(bateau.getForme());
			bateau.pivoter(or);
			Plateaujoueur.placerBateauplateau(bateau.getForme());
		}
		}
		this.finTour();
	}
	
	public void attaquerfusee(Eelementjeu el,int abc,int ord, Flotte fl) {
		if(this.getMissattaq()==4) {
			this.setMissattaq(0);
			this.setTourjoueur(Eaction.FUSEE);
			if(el==Eelementjeu.SOUS_MARIN) {
				plateau plat=fl.getPlateauJoueur();
				Case c=plat.findCase(abc, ord);
				int res=fl.getBateau(Eelementjeu.SOUS_MARIN).maxres();
				Case[] cib= plat.Eclairee(c, res);
				IEclairable[] cibles=cib;
				int[] result=fl.getBateau(Eelementjeu.SOUS_MARIN).eclaireTout(cibles);
				for (int j = 0; j < res; j++) {
					for ( int i=0; i<res ;i++) {
						System.out.print(result[i]);
					}
					System.out.println();
				}
			}
			else {
				System.out.println("ce navire ne peut effectuer cette action");
			}
		}
		else {
			System.out.println("cette action n'est pas disponible");
		}
	}
	
	
	public void finTour() {
		this.setTourjoueur(Eaction.END_TOUR);
	}

	public plateau getPlateaujoueur() {
		return Plateaujoueur;
	}
	
	public void UpgradeAttaq() {
		this.upgradeattq=true;
	}
	
}
