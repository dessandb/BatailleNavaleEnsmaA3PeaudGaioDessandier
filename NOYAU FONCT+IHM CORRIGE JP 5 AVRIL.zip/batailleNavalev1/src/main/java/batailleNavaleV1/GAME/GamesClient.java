package batailleNavaleV1.GAME;

import java.util.Random;

import batailleNavaleV1.ElementsJeux.Bateaux.Eelementjeu;
import batailleNavaleV1.ElementsJeux.Bateaux.Eorientation;
import batailleNavaleV1.comportement.Attaque.IAttaqueBateau;

public class GamesClient {
	
	private static GamesClient instance;

    private int nbtourj1=0;
    private int nbtourj2=0;
    private int nbtourstotal=0;
    private int nbtoursskipj1=0;
    private int nbtoursskipj2=0;
    private Joueur Joueur1;
    private JoueurIA computer;
    private Joueur joueurquijoue;


    private GamesClient() {
        Joueur1= new Joueur("MAX la menace");
        computer=new JoueurIA("JP foucault");
        joueurquijoue=Joueur1;
    }

    public GamesClient getInstance() {
        if(instance == null) {
            instance = new GamesClient();
        }

        return instance;
    }
    
    public Joueur getJoueur1() {
		return Joueur1;
	}

	public void setJoueur1(Joueur joueur1) {
		Joueur1 = joueur1;
	}

	public JoueurIA getComputer() {
		return computer;
	}

	public void setComputer(JoueurIA computer) {
		this.computer = computer;
	}

	public Joueur getJoueurquijoue() {
		return joueurquijoue;
	}

	public void setJoueurquijoue(Joueur joueurquijoue) {
		this.joueurquijoue = joueurquijoue;
	}

	
    public void BonusDefenseIA() {
		if(joueurquijoue==computer) {
			if(Joueur1.getMissattaq()==3) {
				Random rand=new Random();
				int bateaualea=rand.nextInt(7);
				joueurquijoue.getFlottejoueur().getBateau(Eelementjeu.values()[bateaualea]).upgradepv();
				Joueur1.setMissattaq(0);
			}
		}
	}
    public void IA() {
		if(joueurquijoue==computer) {
			computer.ActionAleatoire(Joueur1);
		}
	}
    
    public void SkipTourJoueur() {
		if(joueurquijoue.getTourjoueur()==Eaction.FUSEE){
			joueurquijoue.setTourjoueur(Eaction.SKIP);
			if(joueurquijoue==Joueur1) {
				this.nbtoursskipj1=5;
			}
			else {
				this.nbtoursskipj2=5;
			}
		}
		if(joueurquijoue.getTourjoueur()==Eaction.ATTAQUEENCROIX){
			joueurquijoue.setTourjoueur(Eaction.SKIP);
			if(joueurquijoue==Joueur1) {
				this.nbtoursskipj1=3;
			}
			else {
				this.nbtoursskipj2=3;
			}
		}
	}
    public void BonusAttaque() {
		if(joueurquijoue.getSuccessattaq()==2) {
			joueurquijoue.UpgradeAttaq();
			joueurquijoue.setSuccessattaq(0);
		}
		
		
	}
    
    public void Changementjoueur() {
		if(joueurquijoue==Joueur1) {
			joueurquijoue=computer;
			this.nbtourj1++;
			this.nbtourstotal++;
			joueurquijoue.setTourjoueur(Eaction.DEBUT_TOUR);
		}
		else {
			joueurquijoue=Joueur1;
			this.nbtourj2++;
			this.nbtourstotal++;
			joueurquijoue.setTourjoueur(Eaction.DEBUT_TOUR);
		}
	}
    
    
    
    //CONFERE LE BONUS DEFENSIF AU JOUEUR EN CHOISISSANT SON BATEAU PAR Eelement
	public void BonusDefense(Eelementjeu el) {
		if(joueurquijoue==Joueur1) {
			if(computer.getMissattaq()==3) {
				joueurquijoue.getFlottejoueur().getBateau(el).upgradepv();
				computer.setMissattaq(0);
			}
		}

	}
	// PERMET DE GERER LA FIN DU TOUR LORSQUE LE JOUEUR A EFFECTUE UNE ACTION OU PASSE SON TOUR
	public void FINTOUR() {
		if(joueurquijoue.getTourjoueur()==Eaction.END_TOUR){//(Joueur1.getTourjoueur()==Eaction.SKIP)) {
			this.Changementjoueur();
		}
		if(joueurquijoue.getTourjoueur()==Eaction.SKIP) {
			if(joueurquijoue==Joueur1) {
				if(this.nbtoursskipj1>0) {
					this.Changementjoueur();
					this.nbtoursskipj1--;
				}
				else {
					joueurquijoue.setTourjoueur(Eaction.DEBUT_TOUR);
				}
			}
				else {
					if(this.nbtoursskipj2>0) {
						this.Changementjoueur();
						this.nbtoursskipj2--;
					}
					else {
						joueurquijoue.setTourjoueur(Eaction.DEBUT_TOUR);
					}
				}
			}
		
		}
		
	// PERMET DE REALISER L'ENSEMBLE DES ACTIONS DE L'IA PENDANT UN TOUR DE JEU
	public void TOURIA() {
		this.BonusAttaque();
		this.BonusDefenseIA();
		this.SkipTourJoueur();
		this.IA();
		this.FINTOUR();
	}
	
	// PERMET DE REALISER L'ATTAQUE DU JOUEUR
	public void ATTAQUER(Eelementjeu el, int abc, int ord,IAttaqueBateau comportAttq){
		if(joueurquijoue==Joueur1) {
			this.joueurquijoue.attaquer(el, abc, ord, this.computer.getPlateaujoueur(), comportAttq);
		}
	}
	// PERMET AU JOUEUR D'AVANCER SON BATEAU
	public void AVANCER(Eelementjeu el, int dist) {
		if(joueurquijoue==Joueur1) {
			this.joueurquijoue.move(el, dist);
		}
	}
	// PERMET AU JOUEUR DE PIVOTER SON BATEAU
	public void PIVOTER(Eelementjeu el, Eorientation or) {
		if(joueurquijoue==Joueur1) {
			this.joueurquijoue.move(el, or);
		}
	}
	// PERMET AU JOUEUR DE LANCER UNE FUSEE S'IL EN A UNE
	public void FUSEE(Eelementjeu el,int abc,int ord) {
		if(joueurquijoue==Joueur1) {
			this.joueurquijoue.attaquerfusee(el, abc, ord, computer.getFlottejoueur());
		}
	}
	// PERMET AU JOUEUR DE PLACER SES BATEAUX A L4INITIALISATION
	public void PLACEBATEAU(Eelementjeu el, int abc, int ord, Eorientation or) {
		if(joueurquijoue==Joueur1) {
			this.joueurquijoue.putBateauPlateau(el, abc, ord, or);
		}
	}
	// PERMET D'AVOIR ACCES A LA LONGUEUR DU BATEAU APPELEE PAR SON Eelementjeu
	public int LONGUEURBATEAU(Eelementjeu el) {
		int result=this.Joueur1.getFlottejoueur().getBateau(el).getLongueur();
		return result;
	}
}
