package batailleNavaleV1.plateauJeu;

import java.util.Objects;
import java.util.logging.Logger;

import batailleNavaleV1.comportement.Attaque.IAttaquable;
import batailleNavaleV1.comportement.Attaque.IEclairable;

public class Case implements IAttaquable,IEclairable {
	
	
	private int abcisse=0;
	private int ordonnee=0;
	private int resistance=0;
	protected final static Logger LOGGER = Logger.getLogger(Case.class.getName());
	
	public Case() {
		this.abcisse = 0;
		this.ordonnee = 0;
		this.resistance = 0;
	}

	public int getAbcisse() {
		return abcisse;
	}

	public void setAbcisse(int abcisse) {
		this.abcisse = abcisse;
	}

	public int getOrdonn�e() {
		return ordonnee;
	}

	public void setOrdonn�e(int ordonn�e) {
		this.ordonnee = ordonn�e;
	}

	public int getR�sistance() {
		return resistance;
	}

	public void setR�sistance(int r�sistance) {
		this.resistance = r�sistance;
	}
	
	
	public void estAttaque(final int puiss) throws NullPointerException {
		Objects.requireNonNull(puiss,"Attaque avec puissance null");

		if (this.getR�sistance()==0) { 
			LOGGER.info( " manqu� mudafacka !!!!"); } 
		else if((this.getR�sistance()-puiss)<=0) { 
			LOGGER.info( " d�truit bitch !!!!");
			setR�sistance(0); } 
		else LOGGER.info( " ahah touch� mais pas coul� !!!!");
			this.setR�sistance(this.getR�sistance()-(puiss)); }

	public int estEclairee() {
		return this.getR�sistance();
	}

	  
	/*public IEclairable estEclairee(int abc, int ord , Flotte fl, int res) {
		plateau pl=fl.getPlateauJoueur();
		Case c=pl.findCase(abc, ord);
		Case[] cib= pl.Eclairee(c, res);
		
		
		
	}*/
	


}
