package batailleNavaleV1.ElementsJeux.Bomb;

import batailleNavaleV1.plateauJeu.Case;
import batailleNavaleV1.plateauJeu.plateau;

public class Bombs  {


	private static Bomb bomb1 ;
	private static Bomb bomb2 ;
	
	
	public static Bomb getBomb1() {
		return bomb1;
	}
	public static void setBomb1(Bomb bomb1) {
		Bombs.bomb1 = bomb1;
	}
	public static Bomb getBomb2() {
		return bomb2;
	}
	public static void setBomb2(Bomb bomb2) {
		Bombs.bomb2 = bomb2;
	}
	
	public void changerCase() {
		if (Bombs.bomb1.getCase()==Bombs.bomb2.getCase()) {
			Bombs.bomb1.BombeAleatoire();
			changerCase();
		}
	}
	
	public void checkBombCase(int abc,int ord,int puiss) {
		//finir impl�mentation check bombe identique � getbateau case de flotte et lets go
		Case cposs1=Bombs.getBomb1().getCase();
		Case cposs2=Bombs.getBomb2().getCase();
		if((cposs1.getAbcisse()==abc)&&(cposs1.getOrdonn�e()==ord)) {
			if(puiss<cposs1.getR�sistance()) {
			cposs1.setR�sistance(cposs1.getR�sistance()-puiss);
			}
			else {
				cposs1.setR�sistance(0);
			}
			Bombs.getBomb1().isActive();
		}
		if((cposs2.getAbcisse()==abc)&&(cposs2.getOrdonn�e()==ord)) {
			if(puiss<cposs2.getR�sistance()) {
				cposs2.setR�sistance(cposs2.getR�sistance()-puiss);
				}
				else {
					cposs2.setR�sistance(0);
				}
				Bombs.getBomb2().isActive();
		}
	}
	


}
