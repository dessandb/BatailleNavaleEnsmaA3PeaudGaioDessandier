package batailleNavaleV1.ElementsJeux.Bomb;

import java.util.Random;
import java.util.logging.Logger;

import batailleNavaleV1.comportement.Attaque.Attaquebombemarine;
import batailleNavaleV1.comportement.Attaque.IAttaquable;
import batailleNavaleV1.comportement.Attaque.IAttaqueBombe;
import batailleNavaleV1.plateauJeu.Case;
import batailleNavaleV1.plateauJeu.plateau;

public abstract class Bomb implements IAttaqueBombe {
	
	private boolean exploded=false;
	protected final IAttaqueBombe Attaque=new Attaquebombemarine();
	private final int resistance=3;
	private Case pv = new Case();
	private plateau Plateaujoueur;
	protected final static Logger LOGGER = Logger.getLogger(Bomb.class.getName());
	

	public Bomb() {
		super();
		this.pv.setAbcisse(0);
		this.pv.setOrdonn�e(0);
		this.pv.setR�sistance(resistance);
	}
	
	
	public void explode() {
		if (pv.getR�sistance()==0) {
		exploded = true;
		}
	}
	
	public Case getCase() {
		return pv;
	}

	
	public void BombeAleatoire() {
		Random rand=new Random();
		int AbcisseAlea=rand.nextInt(10);
		int OrdonneeAlea=rand.nextInt(10);
		this.pv.setAbcisse(AbcisseAlea);
		this.pv.setOrdonn�e(OrdonneeAlea);
	}

	public boolean isActive() {
		if(pv.getR�sistance()!=0) {
		return(exploded == false);
	}
		else {
			explode();
			IAttaquable[] cibles=Plateaujoueur.Rayon(this.getCase());
			Attaque.explobombe(cibles);
			return exploded;
		}
}
	
	
}
	
	
