package batailleNavaleV1.ElementsJeux.Bateaux;

public interface IVoilier extends IBateau {
	
}
