package batailleNavaleV1.ElementsJeux.Bateaux;

import batailleNavaleV1.comportement.Attaque.IEclairable;

public interface ISousMarin {
	public int[] eclaireTout(IEclairable[] cibles);
}
