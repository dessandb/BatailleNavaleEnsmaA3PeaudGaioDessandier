package batailleNavaleV1.ElementsJeux.Bateaux;

import batailleNavaleV1.AutomateBateau.etats.IEtat;
import batailleNavaleV1.comportement.Attaque.IAttaquable;
import batailleNavaleV1.comportement.Attaque.IAttaqueBateau;
import batailleNavaleV1.comportement.Attaque.IEclairable;
import batailleNavaleV1.comportement.D�placement.IDeplacable;
import batailleNavaleV1.plateauJeu.Case;

public interface IBateau {
	public void setPv(int ligne, int colonne, Case pv);
	public Case getPv(int ligne, int colonne);
	public IDeplacable getComportementDeplacement();
	public void setComportementDeplacement(IDeplacable compodeplacement);
	public IAttaqueBateau getComportementAttaque();
	public void setComportementAttaque(IAttaqueBateau compoattaque);
	public Case[][] getForme();
	public Case getCaseorigine();
	public void setCaseorigine(Case caseorigine);
	public Eorientation getOrient();
	public void setOrient(Eorientation orient);
	public void setEtatCourant(IEtat et);
	public IEtat getEtatCourant();
	public IEtat getAuRepos();
	public IEtat getEnAttaque();
	public IEtat getEnDeplacement();
	public void arret();
	public void deplacer();
	public void avancer(int puiss);
	public void pivoter(Eorientation orient);
	public void aLAttaque(IAttaquable[] cibles, int puiss);
	public int[] eclaireTout(IEclairable[] cibles);
	public int getLongueur();
	public void setBateau(int abc,int ord, Eorientation or);
	public Case findCasePV(int abc, int ord);
	public boolean estDetruit();
	public int PuissancedeFeu();
	public void setAleatoire();
	public int maxres();
	public void upgradepv();
		
}
