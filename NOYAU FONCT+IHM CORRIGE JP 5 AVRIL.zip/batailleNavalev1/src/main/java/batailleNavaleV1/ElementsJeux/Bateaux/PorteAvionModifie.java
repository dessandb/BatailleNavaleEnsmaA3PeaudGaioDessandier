package batailleNavaleV1.ElementsJeux.Bateaux;

import java.util.Arrays;
import java.util.logging.Logger;

import batailleNavaleV1.comportement.Attaque.Attaqueclassique;
import batailleNavaleV1.comportement.Attaque.Attaqueencroix;
import batailleNavaleV1.comportement.Attaque.IEclairable;
import batailleNavaleV1.comportement.D�placement.Enavancant;
import batailleNavaleV1.comportement.D�placement.Enpivotant;
import batailleNavaleV1.plateauJeu.Case;

public class PorteAvionModifie  extends AbsBateau {
	
	private static final int ligne1 = 5;
	private static final int ligne2 = 3;
	private static final int nbLignes = 2;
	private final static Logger LOGGER = Logger.getLogger(PorteAvionModifie.class.getName());
	public PorteAvionModifie() {
		pv[0] = new Case[ligne1-1];
		pv[1] = new Case[ligne2-1];
		for(int i=0 ; i<ligne1 ; i++) {
			pv[0][i]=new Case();
			pv[0][i].setR�sistance(ligne1);
		}
		for(int i=0 ; i<ligne2 ; i++) {
			pv[1][i]=new Case();
			pv[1][i].setR�sistance(ligne2);
		}
		comportementAttaque= new Attaqueclassique();
		comportementDeplacement=new Enpivotant();
	}
	
	public int getLongueur() {
		return ligne1;
	}

	public static int getLigne2() {
		return ligne2;
	}

	public static int getNblignes() {
		return nbLignes;
	}

	@Override
	public boolean PositionCorrect() {
		if ((this.getOrient()==Eorientation.GAUCHE)&&(((this.getCaseorigine().getAbcisse()-this.getLongueur())<0 )||((this.getCaseorigine().getOrdonn�e()-1)<0))){
				return false;
		}
		else if((this.getOrient()==Eorientation.DROITE)&&(((this.getCaseorigine().getAbcisse()+ this.getLongueur())>10 )||((this.getCaseorigine().getOrdonn�e()+1)>10))){
			return false;
		}
		else if((this.getOrient()==Eorientation.HAUT)&&(((this.getCaseorigine().getOrdonn�e()-this.getLongueur())<0 )||((this.getCaseorigine().getAbcisse()+1)>10))) {
			return false;
		}
		else if((this.getOrient()==Eorientation.BAS)&&(((this.getCaseorigine().getOrdonn�e()+this.getLongueur())>10)||((this.getCaseorigine().getAbcisse()-1)<0))) {
			return false;
		}
		else {
			return true;
			
		}
	}

	public int[] eclaireTout(IEclairable[] cibles) {
		return null;
		// TODO Auto-generated method stub
		
	}
}