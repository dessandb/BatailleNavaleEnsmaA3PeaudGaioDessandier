package batailleNavaleV1.ElementsJeux.Factory;

import batailleNavaleV1.ElementsJeux.Bateaux.Croiseur;
import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;

public class CroiseurFactory extends AbsFactory{
	
	@Override
	public IBateau createBateau() {
		return new Croiseur();
	}
}
