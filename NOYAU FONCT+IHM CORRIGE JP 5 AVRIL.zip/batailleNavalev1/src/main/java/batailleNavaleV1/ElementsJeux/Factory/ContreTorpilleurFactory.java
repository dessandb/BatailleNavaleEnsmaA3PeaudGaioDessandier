package batailleNavaleV1.ElementsJeux.Factory;

import batailleNavaleV1.ElementsJeux.Bateaux.ContreTorpilleur;
import batailleNavaleV1.ElementsJeux.Bateaux.IBateau;

public class ContreTorpilleurFactory extends AbsFactory {

	@Override
	public IBateau createBateau() {
		return new ContreTorpilleur();
	}

}
