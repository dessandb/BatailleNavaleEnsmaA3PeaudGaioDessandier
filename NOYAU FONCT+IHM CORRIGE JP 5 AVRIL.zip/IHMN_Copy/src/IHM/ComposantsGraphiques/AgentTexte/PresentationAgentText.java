package IHM.ComposantsGraphiques.AgentTexte;

public class PresentationAgentText {

	private String leLabel;
	private Boolean editChamp;
	private Boolean enableChamp;
	
	private IVueChampText vue;
	private ModelAgentText mod;
		
	public PresentationAgentText(final Boolean ed, final Boolean en, final String lab) {
		leLabel = lab;
		editChamp = ed;
		enableChamp = en;
		mod = new ModelAgentText();
	}
	
	public void actionTouche(String val) {
		if (mod.setValChamp(val)) {
			vue.notifValeur(val);
		}
	}
	
	public String getValChamp() {
		return mod.getValChamp();
	}
	
	public void setVue(final IVueChampText v) {
		vue = v;
		vue.notifValeur(mod.getValChamp());
		vue.notifEditable(editChamp);
		vue.notifEnable(enableChamp);
	}
	
	public String getLeLabel() {
		return leLabel;
	}
	
	public Boolean getEditChamp() {
		return editChamp;
	}
	
	public void setEditChamp(final Boolean ed) {
		editChamp = ed;
	}
	
	public Boolean getEnableChamp() {
		return enableChamp;
	}
	
	
	
}
