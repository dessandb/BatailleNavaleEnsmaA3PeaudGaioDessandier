package IHM.ComposantsGraphiques.AgentComboBox;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.VBox;

public class VueAgentComboBox extends VBox implements EventHandler<ActionEvent>, IVueComboBox {

	private PresentationAgentComboBox pres;
	
	private ComboBox comboBox;
	
	public VueAgentComboBox(final PresentationAgentComboBox p) {
		pres = p;
		comboBox = new ComboBox<>();
		if (pres.getValueCB()==true) {comboBox.getItems().addAll("Attaquer", "D�placer");}
		else {comboBox.getItems().addAll("gauche", "droite","haut","bas");}
		comboBox.getSelectionModel().select(0);
		getChildren().addAll(comboBox);
		setMinWidth(200d);
		setAlignment(Pos.CENTER);
		comboBox.addEventHandler(ActionEvent.ACTION, this);
	}

	@Override
	public void notifOption(int choix) {
		comboBox.getSelectionModel().clearAndSelect(choix);
	}

	@Override
	public void notifEnable(Boolean enab) {
		this.setDisable(!enab);
	}

	@Override
	public void handle(ActionEvent event) {
		if(event.getEventType() == ActionEvent.ACTION) {
			pres.choisirChoix(comboBox.getSelectionModel().getSelectedIndex());
		}		
		event.consume();
	}

}
