package IHM.ComposantsGraphiques.AgentComboBox;

public interface IAgentComboBoxObservable {
	public void notifyComboBoxAgents();
}
