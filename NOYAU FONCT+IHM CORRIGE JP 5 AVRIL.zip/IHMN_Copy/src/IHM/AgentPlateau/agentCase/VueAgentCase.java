package IHM.AgentPlateau.agentCase;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;


public class VueAgentCase extends Button implements EventHandler<ActionEvent>,IVueAgentCase{
	
	private PresentationAgentCase prezCase;
	private int taille;
	
	public VueAgentCase(PresentationAgentCase p, int t) {
		prezCase = p;
		taille=t;
		resize(getMaxWidth(), getMaxHeight());
		setMinSize(taille, taille);
		this.addEventHandler(ActionEvent.ACTION, this);
		this.setFocusTraversable(true);
	}

	@Override
	public void setTexte(String txt) {setText(txt);}
	@Override
	public void setTaille(int ta) {taille=ta;}
	@Override
	public void handle(ActionEvent event) {
		if(event.getEventType() == ActionEvent.ACTION) {
			prezCase.notifyAgents();
			prezCase.setEditCase(!prezCase.getEditCase());
		}		
		event.consume();
	}

	@Override
	public void notifEditCase() {setDisable(!prezCase.getEditCase());}

	@Override
	public void notifValCase() {setText(prezCase.getValCase());}

}
