package IHM.AgentPlateau;


import javafx.scene.layout.GridPane;

public class VueAgentPlateau extends GridPane implements IVueAgentPlateau{
	private PresentationAgentPlateau pres ;
	
	public VueAgentPlateau(PresentationAgentPlateau p) {
		super();
		pres=p;
		for (int i=0;i<pres.getLigne()+1;i++) {
			for (int j=0;j<pres.getColonne()+1;j++) {
				if (i+j!=0) {
					this.add(p.getEnsembleVueCases()[i][j], j, i);
				}
			}
		}
		//this.setMaxSize(getMinWidth(), getMinHeight());
		//this.resize(getMaxWidth(), getMaxHeight());
	}



}
