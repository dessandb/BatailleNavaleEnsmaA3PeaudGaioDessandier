package IHM.AgentPlateau;

import java.util.ArrayList;

import IHM.AgentPlateau.agentCase.IAgentCaseObservateur;
import IHM.AgentPlateau.agentCase.PresentationAgentCase;
import IHM.AgentPlateau.agentCase.VueAgentCase;

public class PresentationAgentPlateau implements IAgentCaseObservateur{
	private IVueAgentPlateau vuePlateau;

	private ModeleAgentPlateau modPlateau;
	
	private PresentationAgentCase[][] ensemblePrezCases;
	private VueAgentCase[][] ensembleVueCases;
	
	private int ligne,colonne,nbCasesTouchees;
	
	private PresentationAgentCase derniereCaseTouchee;
	
	private ArrayList<IAgentPlateauObservable> observables;
	
	public PresentationAgentPlateau(int l, int c) {
		modPlateau = new ModeleAgentPlateau();
		ligne=l;
		colonne=c;
		nbCasesTouchees=0;
		ensemblePrezCases = new PresentationAgentCase[ligne+1][colonne+1];
		ensembleVueCases = new VueAgentCase[ligne+1][colonne+1];
		for (int i=0;i<ligne+1;i++) {
			for (int j=0;j<colonne+1;j++) {
				if (i+j==0) {}
				else if (i==0) {
					ensemblePrezCases[i][j] = new PresentationAgentCase(false);
					setCase(i,j,Integer.toString(j));
					ensembleVueCases[i][j] = new VueAgentCase(ensemblePrezCases[i][j], 400/ligne);
					ensemblePrezCases[i][j].setVue(ensembleVueCases[i][j]);
					ensemblePrezCases[i][j].ajouterObservateur(this);
				}
				else if (j==0) {
					ensemblePrezCases[i][j] = new PresentationAgentCase(false);
					setCase(i,j,Integer.toString(i));
					ensembleVueCases[i][j] = new VueAgentCase(ensemblePrezCases[i][j], 400/ligne);
					ensemblePrezCases[i][j].setVue(ensembleVueCases[i][j]);
					ensemblePrezCases[i][j].ajouterObservateur(this);
				}
				else {
				ensemblePrezCases[i][j] = new PresentationAgentCase(true);
				ensemblePrezCases[i][j].setPositionColonne(j);
				ensemblePrezCases[i][j].setPositionLigne(i);
				ensembleVueCases[i][j] = new VueAgentCase(ensemblePrezCases[i][j], 400/ligne);
				ensemblePrezCases[i][j].setVue(ensembleVueCases[i][j]);
				ensemblePrezCases[i][j].ajouterObservateur(this);
				}
			}
		}
		observables = new ArrayList<IAgentPlateauObservable>();
		derniereCaseTouchee = null;
	}
	
	public IVueAgentPlateau getVuePlateau() {return vuePlateau;}
	public void setVuePlateau(IVueAgentPlateau vuePlateau) {this.vuePlateau = vuePlateau;}
	public int getNbCasesTouchees() {return nbCasesTouchees;}
	public void setNbCasesTouchees(int nbCasesTouchees) {this.nbCasesTouchees = nbCasesTouchees;}
	public PresentationAgentCase getCase(int i,int j) {return ensemblePrezCases[i][j];}
	public void setCase(int i,int j,String value) {ensemblePrezCases[i][j].setValCase(value);;}
	public void setEditCase(int i,int j,Boolean value) {ensemblePrezCases[i][j].setEditCase(value);}
	public PresentationAgentCase[][] getEnsemblePrezCases() {return ensemblePrezCases;}
	public void setEnsemblePrezCases(PresentationAgentCase[][] ensemblePrezCases) {this.ensemblePrezCases = ensemblePrezCases;}
	public VueAgentCase[][] getEnsembleVueCases() {return ensembleVueCases;}
	public void setEnsembleVueCases(VueAgentCase[][] ensembleVueCases) {this.ensembleVueCases = ensembleVueCases;}
	public int getLigne() {return ligne;}
	public void setLigne(int ligne) {this.ligne = ligne;}
	public int getColonne() {return colonne;}
	public void setColonne(int colonne) {this.colonne = colonne;}
	public void setVue (IVueAgentPlateau vP) {vuePlateau=vP;}
	public PresentationAgentCase getDerniereCaseTouchee() {return derniereCaseTouchee;}
	public void setDerniereCaseTouchee(PresentationAgentCase derniereCaseTouchee) {this.derniereCaseTouchee = derniereCaseTouchee;}
	
	public void notifyAgents() {
		for (IAgentPlateauObservable agent : observables) {
			agent.notifyAgentPlateau(nbCasesTouchees);
		}
	}
	
	public void ajouterObservateur (IAgentPlateauObservable obs) {
		observables.add(obs);
	}
	public void enleverObservateur (IAgentPlateauObservable obs) {
		if (!observables.contains(obs)) {
			observables.remove(obs);
		}
	}

	private void incrementerNbCasesTouchees() {
		 nbCasesTouchees++;
	}
	private void decrementerNbCasesTouchees() {
		nbCasesTouchees--;
	}

	@Override
	public void notifyAgentCase(int positionLigne,int positionColonne) {
		PresentationAgentCase caseTouchee = new PresentationAgentCase(false);
		caseTouchee.setPositionColonne(positionColonne);
		caseTouchee.setPositionLigne(positionLigne);
		setDerniereCaseTouchee(caseTouchee);
		incrementerNbCasesTouchees();
		notifyAgents();
	}
}
