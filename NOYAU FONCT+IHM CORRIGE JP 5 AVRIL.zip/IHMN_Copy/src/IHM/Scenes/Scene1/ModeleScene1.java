package IHM.Scenes.Scene1;

public class ModeleScene1 {

}
