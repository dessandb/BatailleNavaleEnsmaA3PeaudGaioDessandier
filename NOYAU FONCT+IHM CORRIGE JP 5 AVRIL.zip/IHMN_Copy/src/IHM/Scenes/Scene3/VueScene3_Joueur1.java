package IHM.Scenes.Scene3;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class VueScene3_Joueur1 extends BorderPane implements EventHandler<ActionEvent>, IVueScene3_Joueur1{
	private PresentationScene3_Joueur1 pres;
	
	private VBox vb,vTop;
	private HBox hb;
	public VBox getvTop() {
		return vTop;
	}

	public void setvTop(VBox vTop) {
		this.vTop = vTop;
	}

	private Button ok, retour;
	
	public VueScene3_Joueur1 (PresentationScene3_Joueur1 p) {
		super();
		pres=p;
		
		String styleCommandes= "-fx-background-color: rgba(255, 255, 255, 1);"; //rgba(230, 255, 90, 1);
		setStyle(styleCommandes);
		
		Label labTop = new Label("PLATEAU ADVERSE");
		VBox vTop = new VBox();
		vTop.getChildren().addAll(labTop,pres.getVuePlateauAdverse());
		vTop.setAlignment(Pos.TOP_CENTER);
		this.setTop(vTop);
		
		vb = new VBox();
		retour = new Button("RETOUR");
		ok = new Button("OK");
		
		ok.addEventHandler(ActionEvent.ACTION, this);
		
		retour.addEventHandler(ActionEvent.ACTION, this);
		
		hb = new HBox(15);
		
		hb.getChildren().addAll(pres.getVueCBox(),ok);
		this.setCenter(hb);
		
		Label labBottom = new Label("MON PLATEAU ");
		VBox vBottom = new VBox();
		vBottom.getChildren().addAll(labBottom,pres.getVuePlateauJoueur());
		vBottom.setAlignment(Pos.BOTTOM_CENTER);
		this.setBottom(vBottom);
		

	}
	
	public PresentationScene3_Joueur1 getPres() {
		return pres;
	}

	public void setPres(PresentationScene3_Joueur1 pres) {
		this.pres = pres;
	}

	@Override
	public void handle(ActionEvent event) {
		if (event.getSource()==ok) {
			pres.ChoisirAction();
		}
		if (event.getSource()==retour) {
			pres.revenirSurSonChoix();
		}
	}
	
	@Override
	public void createBoutonAccord(String msg,int i) {
		if (i==0) {
		if (this.getChildren().size()>2) {
			if (vb.getChildren().size()>0) {
				vb.getChildren().remove(0);
			}
			this.getChildren().removeAll(vb);
		}
		hb.getChildren().remove(ok);
		if (hb.getChildren().size()>=2) {
			System.out.println("IL FAUT MAINTENANT NOTIFIER LES OBSERVATEURS");
			
			hb.getChildren().remove(1);
			hb.getChildren().add(ok);
			this.setLeft(hb);
		}
		else {
		hb.getChildren().addAll(retour);
		this.setLeft(hb);
		Label lab = new Label(msg);
		vb.getChildren().add(lab);
		this.setRight(vb);
		}

		retour.addEventHandler(ActionEvent.ACTION, this);
		}
		else {
			if (this.getChildren().size()>2) {
				if (vb.getChildren().size()>0) {
					vb.getChildren().remove(0);
				}
				this.getChildren().removeAll(vb);
			}
			if (hb.getChildren().size()>2) {
				hb.getChildren().remove(ok);
			}
			hb.getChildren().addAll(ok);
			this.setLeft(hb);
			Label lab = new Label(msg);
			vb.getChildren().add(lab);
			this.setRight(vb);
			retour.addEventHandler(ActionEvent.ACTION, this);
		}
	}

	@Override
	public void choixBoutonRetour(int i) {
		if (i==0) {
			if (hb.getChildren().size()>2) {
				hb.getChildren().remove(ok);
			}
			else {hb.getChildren().add(ok);}
		hb.getChildren().remove(retour);
		this.setLeft(hb);
		}
		else if (i==1) {
			Label labTop = new Label("PLATEAU ADVERSE");
			VBox vTop = new VBox();
			vTop.getChildren().addAll(labTop,pres.getVuePlateauAdverse());
			vTop.setAlignment(Pos.CENTER);
			this.setTop(vTop);
			hb.getChildren().remove(ok);
			this.setLeft(hb);
		}
	}
}
