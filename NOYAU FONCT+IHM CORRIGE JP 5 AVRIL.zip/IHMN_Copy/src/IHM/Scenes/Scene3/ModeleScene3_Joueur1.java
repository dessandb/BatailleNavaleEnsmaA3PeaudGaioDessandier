package IHM.Scenes.Scene3;

public class ModeleScene3_Joueur1 {

	private Boolean pretAAttaquer ;
	private Boolean pretADeplacer;
	private Boolean choixCase;
	
	public ModeleScene3_Joueur1() {
		pretAAttaquer=false;
		pretADeplacer=false;
		setChoixCase(false);
	}

	public Boolean getPretAAttaquer() {
		return pretAAttaquer;
	}

	public void setPretAAttaquer(Boolean pretAAttaquer) {
		this.pretAAttaquer = pretAAttaquer;
	}

	public Boolean getPretADeplacer() {
		return pretADeplacer;
	}

	public void setPretADeplacer(Boolean pretADeplacer) {
		this.pretADeplacer = pretADeplacer;
	}

	public Boolean getChoixCase() {
		return choixCase;
	}

	public void setChoixCase(Boolean choixCase) {
		this.choixCase = choixCase;
	}
}
