package IHM.Scenes.Scene2;

public class ModeleScene2 {

}
