package Scene1;

import java.util.ArrayList;

import AgentTexte.PresentationAgentText;
import AgentTexte.VueAgentText;
import Scene2.IObservateurScene2;
import Scene2.PresentationScene2;
import Scene2.VueScene2;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;

public class PresentationScene1 implements IObservateurScene2{
	private IVueScene1 vueScene1;
	private ModeleScene1 modScene1;
	
	private PresentationAgentText prezLignes, prezColonnes; 
	private VueAgentText vuelignes,vueColonnes;
	
	private int nbLignes, nbColonnes;
	
	private ArrayList<IObservateurScene1> observateurs;
	
	private PresentationScene2 laPrezApres;
	private VueScene2 leNoeudApres;
	
	private StackPane st;
	
	public PresentationScene1(VueScene2 leNoeudApre, PresentationScene2 laPrezApre, StackPane st) {
		nbLignes=0;
		nbColonnes=0;
		leNoeudApres = leNoeudApre;
		laPrezApres = laPrezApre;
		laPrezApres.setVueScene2(leNoeudApres);
		
		modScene1 = new ModeleScene1();
		
		prezLignes = new PresentationAgentText(true, true, "Nombre de Lignes");
		vuelignes = new VueAgentText(prezLignes);
		prezLignes.setVue(vuelignes);
		
		prezColonnes = new PresentationAgentText(true, true, "Nombre de Colonnes");
		vueColonnes = new VueAgentText(prezColonnes);
		prezColonnes.setVue(vueColonnes);

		observateurs = new ArrayList<IObservateurScene1>();
		
		this.st=st;
	}
	public StackPane getSt() {return st;}
	public void setSt(StackPane st) {this.st = st;}
	public PresentationAgentText getPrezLignes() {return prezLignes;}
	public void setPrezLignes(PresentationAgentText prezLignes) {this.prezLignes = prezLignes;}
	public PresentationAgentText getPrezColonnes() {return prezColonnes;}
	public void setPrezColonnes(PresentationAgentText prezColonnes) {this.prezColonnes = prezColonnes;}
	public int getNbLignes() {return nbLignes;}
	public void setNbLignes(int nbLignes) {this.nbLignes = nbLignes;}
	public int getNbColonnes() {return nbColonnes;}
	public void setNbColonnes(int nbColonnes) {this.nbColonnes = nbColonnes;}
	public void setVueScene1(IVueScene1 vueScene1) {this.vueScene1 = vueScene1;}
	public VueAgentText getVueLignes() {return vuelignes;}
	public void setVuelignes(VueAgentText vuelignes) {this.vuelignes = vuelignes;}
	public VueAgentText getVueColonnes() {return vueColonnes;}
	public void setVueColonnes(VueAgentText vueColonnes) {this.vueColonnes = vueColonnes;}
	public PresentationScene2 getLaPrezApres() {return laPrezApres;}
	public void setLaPrezApres(PresentationScene2 laPrezApres) {this.laPrezApres = laPrezApres;}
	
	public void ajouterObservateur (IObservateurScene1 obs) {observateurs.add(obs);}
	public void enleverObservateur (IObservateurScene1 obs) {if (!observateurs.contains(obs)) {observateurs.remove(obs);}}
	public void notifyAgents() {for (IObservateurScene1 agent : observateurs) {agent.notifyAgentScene1();}}
	
	public void ajouterEnfant(StackPane st ,Node node) {st.getChildren().add(node);setSt(st);}

	
	@Override
	public void notifyScene2() {}
	
}
