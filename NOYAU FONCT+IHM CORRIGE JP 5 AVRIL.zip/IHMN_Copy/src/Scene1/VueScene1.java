package Scene1;

import Scene2.PresentationScene2;
import Scene2.VueScene2;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;

public class VueScene1 extends BorderPane implements IVueScene1, EventHandler<ActionEvent>{
	
	private PresentationScene1 prezScene1;
	private Node leNoeud;
	private Button ok2;
	
	public VueScene1(PresentationScene1 p) {
		prezScene1=p;
		HBox hb = new HBox();
		hb.getChildren().addAll(prezScene1.getVueLignes(),prezScene1.getVueColonnes());
		setCenter(hb);
		String styleCommandes= "-fx-background-color: rgba(255, 255, 255, 1);";
		setStyle(styleCommandes);
		ok2 = new Button("OK");
		ok2.addEventHandler(ActionEvent.ACTION, this);
		setRight(ok2);
	}

	@Override
	public void handle(ActionEvent arg0) {
		if (ok2==arg0.getSource()) {
			  prezScene1.getPrezLignes().actionTouche((prezScene1.getPrezLignes().getValChamp()));
			  PresentationScene2 prezScene2= new PresentationScene2(Integer.parseInt(prezScene1.getPrezLignes().getValChamp()),Integer.parseInt(prezScene1.getPrezColonnes().getValChamp()),prezScene1.getSt());
			 
			  VueScene2 vueScene2 = new VueScene2(prezScene2);
			  prezScene2.setVueScene2(vueScene2);	
		}
	}

	public PresentationScene1 getPrezScene1() {return prezScene1;}
	@Override
	public void setPrezScene1(PresentationScene1 prezScene1) {this.prezScene1 = prezScene1;}
	public Node getLeNoeud() {return leNoeud;}
	public void setLeNoeud(Node leNoeud) {this.leNoeud = leNoeud;}
}
