package AgentGlobal;

public class VueAgentGlobal {

}
