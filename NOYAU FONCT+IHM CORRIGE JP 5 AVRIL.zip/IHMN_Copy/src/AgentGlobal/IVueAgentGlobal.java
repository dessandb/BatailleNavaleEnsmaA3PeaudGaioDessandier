package AgentGlobal;

public interface IVueAgentGlobal {

}
