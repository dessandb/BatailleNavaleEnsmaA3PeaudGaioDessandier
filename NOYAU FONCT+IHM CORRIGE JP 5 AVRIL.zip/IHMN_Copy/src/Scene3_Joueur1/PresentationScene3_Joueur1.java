
package Scene3_Joueur1;

import java.util.ArrayList;

//import AgentCase.PresentationAgentCase;
import AgentComboBox.IAgentComboBoxObservable;
import AgentComboBox.PresentationAgentComboBox;
import AgentComboBox.VueAgentComboBox;
import AgentPlateau.IAgentPlateauObservable;
import AgentPlateau.PresentationAgentPlateau;
import AgentPlateau.VueAgentPlateau;
import javafx.scene.layout.StackPane;

public class PresentationScene3_Joueur1 implements IAgentComboBoxObservable,IAgentPlateauObservable{
	private IVueScene3_Joueur1 vuePartie;
	private ModeleScene3_Joueur1 modPartie;
	
	private PresentationAgentPlateau prezPlateauJoueur,prezPlateauAdverse;
	private VueAgentPlateau vuePlateauJoueur, vuePlateauAdverse;
	
	private ArrayList<IObservateurScene3_Joueur1> observateurs;
	
	private int ligne,colonne ;
	
	private PresentationAgentComboBox prezCBox;
	private VueAgentComboBox vueCBox;
	
	public StackPane getSt() {
		return st;
	}
	public void setSt(StackPane st) {
		this.st = st;
	}

	private StackPane st;
	
	private Boolean caseEstTouchee;
	
	public PresentationScene3_Joueur1(int l, int c, StackPane st) {
		modPartie = new ModeleScene3_Joueur1();
		ligne=l;
		colonne=c;
		prezPlateauJoueur = new PresentationAgentPlateau(ligne, colonne);
		prezPlateauAdverse = new PresentationAgentPlateau(ligne, colonne);
		/*
		 * for (int i=1;i<ligne+1;i++) { for (int j=1;j<colonne+1;j++) {
		 * prezPlateauJoueur.setEditCase(i, j, false); } }
		 */
		vuePlateauJoueur = new VueAgentPlateau(prezPlateauJoueur);
		vuePlateauAdverse = new VueAgentPlateau(prezPlateauAdverse);
		prezPlateauJoueur.setVue(vuePlateauJoueur);
		prezPlateauAdverse.setVue(vuePlateauAdverse);
		//choixCase = prezPlateauAdverse.getDerniereCaseTouchee();
		prezPlateauAdverse.ajouterObservateur(this);
		
		prezCBox = new PresentationAgentComboBox(true,true);
		vueCBox = new VueAgentComboBox(prezCBox);
		prezCBox.setVue(vueCBox);
		
		observateurs = new ArrayList<IObservateurScene3_Joueur1>();
		
		prezCBox.ajouterObservateur(this);
		
		caseEstTouchee=false;
		this.st=st;
	}
	public void ajouterObservateur (IObservateurScene3_Joueur1 obs) {
		observateurs.add(obs);
	}
	
	public void enleverObservateur (IObservateurScene3_Joueur1 obs) {
		if (!observateurs.contains(obs)) {
			observateurs.remove(obs);
		}
	}
	public void notifyAgents() {
		for (IObservateurScene3_Joueur1 agent : observateurs) {
			agent.notifyScene3();
		}
	}
	
	
	public PresentationAgentComboBox getPrezCBox() {
		return prezCBox;
	}

	public void setPrezCBox(PresentationAgentComboBox prezCBox) {
		this.prezCBox = prezCBox;
	}

	public VueAgentComboBox getVueCBox() {
		return vueCBox;
	}

	public void setVueCBox(VueAgentComboBox vueCBox) {
		this.vueCBox = vueCBox;
	}

	//Getters and Setters
	public PresentationAgentPlateau getPrezPlateauJoueur() {return prezPlateauJoueur;}
	public void setPrezPlateauJoueur(PresentationAgentPlateau prezPlateauJoueur) {this.prezPlateauJoueur = prezPlateauJoueur;}
	public PresentationAgentPlateau getPrezPlateauAdverse() {return prezPlateauAdverse;}
	public void setPrezPlateauAdverse(PresentationAgentPlateau prezPlateauAdverse) {this.prezPlateauAdverse = prezPlateauAdverse;}
	public VueAgentPlateau getVuePlateauJoueur(){return vuePlateauJoueur;}
	public void setVuePlateauJoueur(VueAgentPlateau vuePlateauJoueur) {this.vuePlateauJoueur = vuePlateauJoueur;}
	public VueAgentPlateau getVuePlateauAdverse() {return vuePlateauAdverse;}
	public void setVuePlateauAdverse(VueAgentPlateau vuePlateauAdverse) {this.vuePlateauAdverse = vuePlateauAdverse;}
	public int getLigne() {return ligne;}
	public void setLigne(int ligne) {this.ligne = ligne;}
	public int getColonne() {return colonne;}
	public void setColonne(int colonne) {this.colonne = colonne;}
	public IVueScene3_Joueur1 getVuePartie() {return vuePartie;}
	public void setVuePartie(IVueScene3_Joueur1 vuePartie) {this.vuePartie = vuePartie;}
	
	public void revenirSurSonChoix() {
		if (modPartie.getPretAAttaquer()==true) {
			if (caseEstTouchee==false) {
			vuePartie.choixBoutonRetour(0);}
			else {
				prezPlateauAdverse.setEditCase(prezPlateauAdverse.getDerniereCaseTouchee().
				getPositionColonne(),
				prezPlateauAdverse.getDerniereCaseTouchee().getPositionLigne(),
				!prezPlateauAdverse.getDerniereCaseTouchee().getEditCase());
				vuePlateauAdverse = new VueAgentPlateau(prezPlateauAdverse);
				prezPlateauAdverse.setVue(vuePlateauAdverse);
				vuePartie.choixBoutonRetour(1);
				
			}
		}
		else if (modPartie.getPretADeplacer()==true) {
			vuePartie.choixBoutonRetour(0);
		}
		/*
		 * modPartie.setPretAAttaquer(false); modPartie.setPretADeplacer(false);
		 * prezPlateauAdverse.setEditCase(prezPlateauAdverse.getDerniereCaseTouchee().
		 * getPositionColonne(),
		 * prezPlateauAdverse.getDerniereCaseTouchee().getPositionLigne(),
		 * !prezPlateauAdverse.getDerniereCaseTouchee().getEditCase());
		 * vuePlateauAdverse = new VueAgentPlateau(prezPlateauAdverse);
		 * prezPlateauAdverse.setVue(vuePlateauAdverse);
		 */
		caseEstTouchee=false;
	}
	public void ChoisirAction() {
		String msg;
		if (prezCBox.getVal()==0) {
			modPartie.setPretAAttaquer(true);
			msg = "Vous voulez Attaquer. Cliquer sur une Case pour Attaquer";}
		else {
			modPartie.setPretADeplacer(true);
			msg="Vous voulez d�placer le bateau que vous souhaitez. Cliquer sur un bateau svp.";
		}
		
		vuePartie.createBoutonAccord(msg,0);
		
	}
	
	public void ChoisirCase() {
		caseEstTouchee=true;
		String msg = "Vous voulez attaquer la Case situ� � la Ligne : " +
				getPrezPlateauAdverse().getDerniereCaseTouchee().getPositionLigne()+
					", et la Colonne :"
				+getPrezPlateauAdverse().getDerniereCaseTouchee().getPositionColonne();
		
		vuePartie.createBoutonAccord(msg,1);
	}

	@Override
	public void notifyAgentPlateau(int i) {
		if (modPartie.getPretAAttaquer()==true) {ChoisirCase();}else {}
		notifyAgents();
	}

	@Override
	public void notifyComboBoxAgents() {
		// TODO Auto-generated method stub
		
	}
	
}
