package AgentComboBox;

public interface IAgentComboBoxObservable {
	public void notifyComboBoxAgents();
}
