package Scene2;

import java.util.ArrayList;

import AgentComboBox.IAgentComboBoxObservable;
import AgentComboBox.PresentationAgentComboBox;
import AgentComboBox.VueAgentComboBox;
import AgentPlateau.IAgentPlateauObservable;
import AgentPlateau.PresentationAgentPlateau;
import AgentPlateau.VueAgentPlateau;
import AgentPlateau.agentCase.PresentationAgentCase;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;

public class PresentationScene2 implements IAgentPlateauObservable, IAgentComboBoxObservable{
	private IVueScene2 vueScene2;
	private ModeleScene2 modScene2;
	
	private PresentationAgentPlateau prezPlateau;
	private VueAgentPlateau vuePlateau;
	
	private int ligne,colonne,nbCasesTouchees;
	
	private Boolean bateauPlaces,etatAvant;
	
	private PresentationAgentCase caseTouchee;
	
	private PresentationAgentComboBox pCBox;
	private VueAgentComboBox vCBox;

	private StackPane st;

	private ArrayList<IObservateurScene2> observateurs;
	
	public PresentationScene2(int l,int c,StackPane st) {

		modScene2 = new ModeleScene2();
		ligne=l;
		colonne=c;
		
		prezPlateau = new PresentationAgentPlateau(ligne, colonne);
		vuePlateau = new VueAgentPlateau(prezPlateau);
		vuePlateau.setMaxSize(450, 450);
		vuePlateau.setHgap(0);
		prezPlateau.setVue(vuePlateau);
		prezPlateau.ajouterObservateur(this);
		
		nbCasesTouchees = prezPlateau.getNbCasesTouchees();
		bateauPlaces=false;
		etatAvant=false;
		this.st=st;
		
		caseTouchee=null;
		
		pCBox = new PresentationAgentComboBox(true,false);
		vCBox = new VueAgentComboBox(pCBox);
		pCBox.setVue(vCBox);
		
		pCBox.ajouterObservateur(this);
		
		observateurs = new ArrayList<IObservateurScene2>();
	
	}
	
	
	public StackPane getSt() {return st;}
	public void setSt(StackPane st) {this.st = st;}
	
	public PresentationAgentComboBox getpCBox() {return pCBox;}
	public void setpCBox(PresentationAgentComboBox pCBox) {this.pCBox = pCBox;}
	public VueAgentComboBox getvCBox() {return vCBox;}
	public void setvCBox(VueAgentComboBox vCBox) {this.vCBox = vCBox;}

	public Boolean getBateauPlaces() {if (nbCasesTouchees==5) {bateauPlaces=true;}
									else {bateauPlaces=false;}
									return bateauPlaces;}

	public PresentationAgentPlateau getPrezPlateau() {return prezPlateau;}
	public void setPrezPlateau(PresentationAgentPlateau prezPlateau) {this.prezPlateau = prezPlateau;}
	public VueAgentPlateau getVuePlateau() {return vuePlateau;}
	public void setVuePlateau(VueAgentPlateau vuePlateau) {this.vuePlateau = vuePlateau;}
	public int getLigne() {return ligne;}
	public void setLigne(int ligne) {this.ligne = ligne;}
	public int getColonne() {return colonne;}
	public void setColonne(int colonne) {this.colonne = colonne;}
	public void setVueScene2(IVueScene2 vueScene2) {this.vueScene2 = vueScene2;}
	public IVueScene2 getVueScene2() {return vueScene2;}
	public void setBateauPlaces(Boolean bateauPlaces) {this.bateauPlaces = bateauPlaces;}
	public Boolean getEtatAvant() {return etatAvant;}
	public void setEtatAvant(Boolean etatAvant) {this.etatAvant = etatAvant;}
	public int getNbCasesTouchees() {return nbCasesTouchees;}
	public void setNbCasesTouchees(int nbCasesTouchees) {this.nbCasesTouchees = nbCasesTouchees;getPrezPlateau().setNbCasesTouchees(getPrezPlateau().getNbCasesTouchees()-1);}
	public PresentationAgentCase getCaseTouchee() {return caseTouchee;}
	public void setCaseTouchee(PresentationAgentCase caseTouchee) {this.caseTouchee = caseTouchee;}

	
	public void revenirSurSonChoix() {
		prezPlateau.setEditCase(prezPlateau.getDerniereCaseTouchee().getPositionColonne(), prezPlateau.getDerniereCaseTouchee().getPositionLigne(), !prezPlateau.getDerniereCaseTouchee().getEditCase());
		vuePlateau = new VueAgentPlateau(prezPlateau);
		prezPlateau.setVue(vuePlateau);
	}
	public void ChoisirCase() {
		vueScene2.createBoutonAccord();
	}
	
	@Override
	public void notifyAgentPlateau(int i) {
		nbCasesTouchees=i;
		ChoisirCase();
		caseTouchee=prezPlateau.getDerniereCaseTouchee();
		notifyAgents();
	}

	public void ajouterObservateur (IObservateurScene2 obs) {observateurs.add(obs);}
	public void enleverObservateur (IObservateurScene2 obs) {if (!observateurs.contains(obs)) {observateurs.remove(obs);}}
	public void notifyAgents() {for (IObservateurScene2 agent : observateurs) {agent.notifyScene2();}}

	public void ajouterEnfant(StackPane st ,Node node) {
		st.getChildren().remove(0);
		st.getChildren().add(node);
		setSt(st);
		
	}

	@Override
	public void notifyComboBoxAgents() {}
	
}
