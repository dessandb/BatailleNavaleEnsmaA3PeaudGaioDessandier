package AgentPlateau;

public class ModeleAgentPlateau {

}
