package AgentPlateau.agentCase;

import java.util.ArrayList;

public class PresentationAgentCase {

	private Boolean editCase;
	private ModeleAgentCase mod;
	private IVueAgentCase vue;
	private String valCase ;
	private int positionLigne, positionColonne;
	
	private ArrayList<IAgentCaseObservateur> observateurs;
	
	public PresentationAgentCase(final Boolean ed) {
		valCase = new String();
		editCase = ed;
		mod = new ModeleAgentCase();
		observateurs = new ArrayList<IAgentCaseObservateur>();
		positionColonne =0;
		positionLigne =0;
	}
	
	public IVueAgentCase getVue() {
		return vue;
	}

	public void setVue (IVueAgentCase v) {
		vue=v;
		setEditCase(getEditCase());
		if (valCase!="") {
			setValCase(valCase);
		}
	}
	
	public Boolean getEditCase() {
		return editCase;
	}
	
	public void setEditCase(Boolean ed) {
		editCase=ed;
		mod.setEnableCase(ed);
		vue.notifEditCase();
		vue.notifValCase();
	}

	public String getValCase(){
		return valCase;
	}
	
	public void setValCase(String vC) {
		valCase = vC;
		mod.setValCase(vC);
	}
	
	public void notifyAgents() {
		for (IAgentCaseObservateur agent : observateurs) {
			agent.notifyAgentCase(getPositionLigne(),getPositionColonne());
		}
	}
	
	public void ajouterObservateur (IAgentCaseObservateur obs) {
		observateurs.add(obs);
	}
	
	public void enleverObservateur (IAgentCaseObservateur obs) {
		if (!observateurs.contains(obs)) {
			observateurs.remove(obs);
		}
	}

	public int getPositionLigne() {
		return positionLigne;
	}

	public void setPositionLigne(int positionLigne) {
		this.positionLigne = positionLigne;
	}

	public int getPositionColonne() {
		return positionColonne;
	}

	public void setPositionColonne(int positionColonne) {
		this.positionColonne = positionColonne;
	} 
}
