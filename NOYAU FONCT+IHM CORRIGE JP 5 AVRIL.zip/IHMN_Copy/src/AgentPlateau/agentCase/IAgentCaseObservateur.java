package AgentPlateau.agentCase;

public interface IAgentCaseObservateur {
	public void notifyAgentCase(int positionLigne, int positionColonne);
}
