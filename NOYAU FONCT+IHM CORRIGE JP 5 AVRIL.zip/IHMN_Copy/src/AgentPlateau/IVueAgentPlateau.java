package AgentPlateau;

public interface IVueAgentPlateau {

}
