package Tests;

import IHM.Scenes.Scene3.PresentationScene3_Joueur1;
import IHM.Scenes.Scene3.VueScene3_Joueur1;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class TestScene3 extends Application {
		@Override
		public void start(Stage primaryStage) {
			try {
				PresentationScene3_Joueur1 prezIHM = new PresentationScene3_Joueur1(10, 9,new StackPane());
				VueScene3_Joueur1 vueIHM = new VueScene3_Joueur1(prezIHM);
				prezIHM.setVuePartie(vueIHM);
				Scene scene = new Scene(vueIHM,400,400);
				primaryStage.setTitle("TEST SCENE 3");
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStage.setScene(scene);
				primaryStage.setMinHeight(800);
				primaryStage.setMinWidth(800);
				primaryStage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		public static void main(String[] args) {
			launch(args);
		}
}
