package Tests;

import IHM.AgentPlateau.PresentationAgentPlateau;
import IHM.AgentPlateau.VueAgentPlateau;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class TestPlateau extends Application{

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		try {
			PresentationAgentPlateau prezPlateau = new PresentationAgentPlateau(10, 11);
			VueAgentPlateau vuePlateau = new VueAgentPlateau(prezPlateau);
			prezPlateau.setVue(vuePlateau);
			System.out.println(prezPlateau.getEnsemblePrezCases()[2][2]);
			PresentationAgentPlateau prezPlateau2 = new PresentationAgentPlateau(10, 10);
			VueAgentPlateau vuePlateau2 = new VueAgentPlateau(prezPlateau2);
			prezPlateau2.setVue(vuePlateau2);
			BorderPane bp1 = new BorderPane();
			bp1.setLeft(vuePlateau);
			bp1.setRight(vuePlateau2);
			Scene scene = new Scene(bp1,400,400);
			primaryStage.setTitle("TEST_PLATEAU");
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setMinHeight(800);
			primaryStage.setMinWidth(800);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
