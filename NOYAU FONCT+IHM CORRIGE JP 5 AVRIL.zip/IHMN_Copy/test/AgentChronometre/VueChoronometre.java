package AgentChronometre;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class VueChoronometre extends StackPane implements IVueChronometre,EventHandler<ActionEvent>{
    private Timeline timeline;
    private Label timerLabel ;
    private DoubleProperty timeSeconds;
    private Duration time;
    private Button start,stop;
    private VBox vb;

    public VueChoronometre() {
		timerLabel = new Label();
		timeSeconds = new SimpleDoubleProperty();
		time = Duration.ZERO;
		
        timerLabel.textProperty().bind(timeSeconds.asString());
        timerLabel.setTextFill(Color.RED);
        timerLabel.setStyle("-fx-font-size: 4em;");
       
        start = new Button(); start.setText("Start/Restart");
        start.addEventHandler(ActionEvent.ACTION,this);
        stop = new Button("Stop"); stop.addEventHandler(ActionEvent.ACTION,this);
        
        vb = new VBox(20);vb.setAlignment(Pos.CENTER);
        vb.getChildren().addAll(start, timerLabel,stop);this.getChildren().add(vb);
	}

	public Timeline getTimeline() {return timeline;}
	public void setTimeline(Timeline timeline) {this.timeline = timeline;}
	public Label getTimerLabel() {return timerLabel;}
	public void setTimerLabel(Label timerLabel) {this.timerLabel = timerLabel;}
	public DoubleProperty getTimeSeconds() {return timeSeconds;}
	public void setTimeSeconds(DoubleProperty timeSeconds) {this.timeSeconds = timeSeconds;}
	public Duration getTime() {return time;}
	public void setTime(Duration time) {this.time = time;}
	
	@Override
	public void relancerChronoAZero () {time = Duration.ZERO;timeSeconds.set(time.toSeconds());}
	@Override
	public void arretChrono() {timeline.stop();timeline=null;}
	@Override
	public void demarrerChrono(int i) {
		 setTimeline(new Timeline(
                 new KeyFrame(Duration.millis(100),
                 new EventHandler<ActionEvent>() {
                     @Override
                     public void handle(ActionEvent t) {
                         Duration duration = ((KeyFrame)t.getSource()).getTime();
                         time = time.add(duration);
                         timeSeconds.set(time.toSeconds());
                      }
                 })
             ));
             timeline.setCycleCount(i);
             timeline.play();

	}
	
	@Override
	public void handle(ActionEvent event) {
		if (event.getSource()==start) {
			 if (timeline != null) {
             	relancerChronoAZero();
             } else {
                demarrerChrono(1800);
             }
		}
		else if (event.getSource()==stop) {
			relancerChronoAZero();
        	arretChrono();
		}	
	}
}
